from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, EmailStr
from typing import List, Optional
from datetime import datetime, timedelta
from asgiref.sync import sync_to_async
import jwt
import os
import sys

# Add the current directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Configure Django settings
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'event_management.settings')

# Import Django models
import django
django.setup()

from events.models import College, CustomUser, Event, Registration, Attendance, Feedback

# FastAPI app
app = FastAPI(title="Campus Event Management API", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# JWT Configuration
SECRET_KEY = "your-secret-key-here-hardcoded-for-development"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

security = HTTPBearer()

# Pydantic Models
class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None

class UserBase(BaseModel):
    username: str
    email: EmailStr
    name: str
    college_id: int
    roll_no: Optional[str] = None
    department: str
    date_of_birth: Optional[datetime] = None

class UserCreate(UserBase):
    password: str

class UserLogin(BaseModel):
    username: str
    password: str

class EventBase(BaseModel):
    title: str
    description: str
    event_type: str
    start_time: datetime
    end_time: datetime
    college_id: int

class EventResponse(BaseModel):
    id: int
    title: str
    description: str
    event_type: str
    start_time: datetime
    end_time: datetime
    college_id: int
    college_name: str
    created_by_name: str
    status: str
    created_at: datetime
    registration_count: int

class RegistrationResponse(BaseModel):
    id: int
    event_id: int
    event_title: str
    registered_at: datetime

class AttendanceBase(BaseModel):
    student_id: int
    status: str

class FeedbackBase(BaseModel):
    rating: int
    comments: Optional[str] = None

class FeedbackResponse(BaseModel):
    id: int
    event_id: int
    event_title: str
    rating: int
    comments: Optional[str] = None
    submitted_at: datetime

# JWT Functions
def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise HTTPException(status_code=401, detail="Invalid authentication credentials")
        return username
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid authentication credentials")

@sync_to_async
def get_current_user_sync(username: str):
    try:
        user = CustomUser.objects.get(username=username)
        return user
    except CustomUser.DoesNotExist:
        raise HTTPException(status_code=401, detail="User not found")

async def get_current_user(username: str = Depends(verify_token)):
    return await get_current_user_sync(username)

# API Endpoints

@sync_to_async
def register_student_sync(user_data: UserCreate):
    """Register a new student"""
    try:
        # Check if college exists
        college = College.objects.get(id=user_data.college_id)

        # Check if username or email already exists
        if CustomUser.objects.filter(username=user_data.username).exists():
            raise HTTPException(status_code=400, detail="Username already exists")
        if CustomUser.objects.filter(email=user_data.email).exists():
            raise HTTPException(status_code=400, detail="Email already exists")

        # Create user
        user = CustomUser.objects.create_user(
            username=user_data.username,
            email=user_data.email,
            password=user_data.password,
            name=user_data.name,
            college=college,
            roll_no=user_data.roll_no,
            department=user_data.department,
            date_of_birth=user_data.date_of_birth
        )

        # Create access token
        access_token = create_access_token(
            data={"sub": user.username},
            expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        )

        return {
            "message": "Student registered successfully",
            "user": {
                "id": user.id,
                "username": user.username,
                "email": user.email,
                "name": user.name,
                "college": user.college.name,
                "roll_no": user.roll_no,
                "department": user.department
            },
            "access_token": access_token,
            "token_type": "bearer"
        }
    except College.DoesNotExist:
        raise HTTPException(status_code=400, detail="College not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/students", response_model=dict)
async def register_student(user_data: UserCreate):
    """Register a new student"""
    return await register_student_sync(user_data)

@sync_to_async
def login_student_sync(login_data: UserLogin):
    """Login for students"""
    try:
        user = CustomUser.objects.get(username=login_data.username)
        if not user.check_password(login_data.password):
            raise HTTPException(status_code=401, detail="Invalid credentials")

        if not user.is_active:
            raise HTTPException(status_code=401, detail="Account is disabled")

        access_token = create_access_token(
            data={"sub": user.username},
            expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        )

        return {
            "message": "Login successful",
            "user": {
                "id": user.id,
                "username": user.username,
                "email": user.email,
                "name": user.name,
                "college": user.college.name if user.college else None,
                "roll_no": user.roll_no,
                "department": user.department
            },
            "access_token": access_token,
            "token_type": "bearer"
        }
    except CustomUser.DoesNotExist:
        raise HTTPException(status_code=401, detail="Invalid credentials")

@app.post("/auth/login", response_model=dict)
async def login_student(login_data: UserLogin):
    """Login for students"""
    return await login_student_sync(login_data)

@sync_to_async
def get_events_sync(current_user: CustomUser, event_type: Optional[str] = None, college_id: Optional[int] = None):
    """Get all active events"""
    queryset = Event.objects.filter(status='published')

    if event_type:
        queryset = queryset.filter(event_type=event_type)
    if college_id:
        queryset = queryset.filter(college_id=college_id)

    events = queryset.order_by('-created_at')

    result = []
    for event in events:
        registration_count = Registration.objects.filter(event=event).count()
        result.append({
            "id": event.id,
            "title": event.title,
            "description": event.description,
            "event_type": event.event_type,
            "start_time": event.start_time,
            "end_time": event.end_time,
            "college_id": event.college.id,
            "college_name": event.college.name,
            "created_by_name": event.created_by.name,
            "status": event.status,
            "created_at": event.created_at,
            "registration_count": registration_count
        })

    return result

@app.get("/events", response_model=List[EventResponse])
async def get_events(
    current_user: CustomUser = Depends(get_current_user),
    event_type: Optional[str] = None,
    college_id: Optional[int] = None
):
    """Get all active events"""
    return await get_events_sync(current_user, event_type, college_id)

@sync_to_async
def get_event_details_sync(event_id: int, current_user: CustomUser):
    """Get event details"""
    try:
        event = Event.objects.get(id=event_id, status='published')
        registration_count = Registration.objects.filter(event=event).count()

        return {
            "id": event.id,
            "title": event.title,
            "description": event.description,
            "event_type": event.event_type,
            "start_time": event.start_time,
            "end_time": event.end_time,
            "college_id": event.college.id,
            "college_name": event.college.name,
            "created_by_name": event.created_by.name,
            "status": event.status,
            "created_at": event.created_at,
            "registration_count": registration_count
        }
    except Event.DoesNotExist:
        raise HTTPException(status_code=404, detail="Event not found")

@app.get("/events/{event_id}", response_model=EventResponse)
async def get_event_details(
    event_id: int,
    current_user: CustomUser = Depends(get_current_user)
):
    """Get event details"""
    return await get_event_details_sync(event_id, current_user)

@sync_to_async
def register_for_event_sync(event_id: int, current_user: CustomUser):
    """Register for an event"""
    try:
        event = Event.objects.get(id=event_id, status='published')

        # Check if already registered
        if Registration.objects.filter(event=event, student=current_user).exists():
            raise HTTPException(status_code=400, detail="Already registered for this event")

        # Check if event has started
        from django.utils import timezone
        if event.start_time <= timezone.now():
            raise HTTPException(status_code=400, detail="Event has already started")

        registration = Registration.objects.create(event=event, student=current_user)

        return {
            "message": "Successfully registered for event",
            "registration": {
                "id": registration.id,
                "event_title": event.title,
                "registered_at": registration.registered_at
            }
        }
    except Event.DoesNotExist:
        raise HTTPException(status_code=404, detail="Event not found")

@app.post("/events/{event_id}/register", response_model=dict)
async def register_for_event(
    event_id: int,
    current_user: CustomUser = Depends(get_current_user)
):
    """Register for an event"""
    return await register_for_event_sync(event_id, current_user)

@sync_to_async
def get_student_registrations_sync(current_user: CustomUser):
    """Get student's event registrations"""
    registrations = Registration.objects.filter(student=current_user).select_related('event')

    result = []
    for reg in registrations:
        result.append({
            "id": reg.id,
            "event_id": reg.event.id,
            "event_title": reg.event.title,
            "registered_at": reg.registered_at
        })

    return result

@app.get("/students/registrations", response_model=List[RegistrationResponse])
async def get_student_registrations(current_user: CustomUser = Depends(get_current_user)):
    """Get student's event registrations"""
    return await get_student_registrations_sync(current_user)

@sync_to_async
def mark_attendance_sync(event_id: int, attendance_data: AttendanceBase, current_user: CustomUser):
    """Mark attendance for an event (staff only)"""
    if not current_user.is_staff:
        raise HTTPException(status_code=403, detail="Only staff can mark attendance")

    try:
        event = Event.objects.get(id=event_id)
        student = CustomUser.objects.get(id=attendance_data.student_id)

        # Check if student is registered
        if not Registration.objects.filter(event=event, student=student).exists():
            raise HTTPException(status_code=400, detail="Student is not registered for this event")

        attendance, created = Attendance.objects.update_or_create(
            event=event,
            student=student,
            defaults={'status': attendance_data.status}
        )

        return {
            "message": "Attendance marked successfully",
            "attendance": {
                "id": attendance.id,
                "event_title": event.title,
                "student_name": student.name,
                "status": attendance.status,
                "marked_at": attendance.marked_at
            }
        }
    except Event.DoesNotExist:
        raise HTTPException(status_code=404, detail="Event not found")
    except CustomUser.DoesNotExist:
        raise HTTPException(status_code=404, detail="Student not found")

@app.post("/events/{event_id}/attendance", response_model=dict)
async def mark_attendance(
    event_id: int,
    attendance_data: AttendanceBase,
    current_user: CustomUser = Depends(get_current_user)
):
    """Mark attendance for an event (staff only)"""
    return await mark_attendance_sync(event_id, attendance_data, current_user)

@sync_to_async
def submit_feedback_sync(event_id: int, feedback_data: FeedbackBase, current_user: CustomUser):
    """Submit feedback for an event"""
    try:
        event = Event.objects.get(id=event_id)

        # Check if student attended the event
        if not Attendance.objects.filter(event=event, student=current_user, status='present').exists():
            raise HTTPException(status_code=400, detail="You must attend the event to submit feedback")

        feedback, created = Feedback.objects.update_or_create(
            event=event,
            student=current_user,
            defaults={
                'rating': feedback_data.rating,
                'comments': feedback_data.comments or ''
            }
        )

        return {
            "message": "Feedback submitted successfully",
            "feedback": {
                "id": feedback.id,
                "event_title": event.title,
                "rating": feedback.rating,
                "comments": feedback.comments,
                "submitted_at": feedback.submitted_at
            }
        }
    except Event.DoesNotExist:
        raise HTTPException(status_code=404, detail="Event not found")

@app.post("/events/{event_id}/feedback", response_model=dict)
async def submit_feedback(
    event_id: int,
    feedback_data: FeedbackBase,
    current_user: CustomUser = Depends(get_current_user)
):
    """Submit feedback for an event"""
    return await submit_feedback_sync(event_id, feedback_data, current_user)

@sync_to_async
def get_student_feedback_sync(current_user: CustomUser):
    """Get student's submitted feedback"""
    feedback_list = Feedback.objects.filter(student=current_user).select_related('event')

    result = []
    for fb in feedback_list:
        result.append({
            "id": fb.id,
            "event_id": fb.event.id,
            "event_title": fb.event.title,
            "rating": fb.rating,
            "comments": fb.comments,
            "submitted_at": fb.submitted_at
        })

    return result

@app.get("/students/feedback", response_model=List[FeedbackResponse])
async def get_student_feedback(current_user: CustomUser = Depends(get_current_user)):
    """Get student's submitted feedback"""
    return await get_student_feedback_sync(current_user)

@sync_to_async
def get_colleges_sync():
    """Get all colleges"""
    colleges = College.objects.all()
    return [{"id": c.id, "name": c.name, "location": c.location} for c in colleges]

@app.get("/colleges", response_model=List[dict])
async def get_colleges():
    """Get all colleges"""
    return await get_colleges_sync()

@sync_to_async
def get_event_reports_sync(current_user: CustomUser):
    """Get event popularity reports"""
    if not current_user.is_staff:
        raise HTTPException(status_code=403, detail="Only staff can access reports")

    from django.db.models import Count, Avg

    events = Event.objects.annotate(
        registration_count=Count('registrations'),
        attendance_count=Count('attendance'),
        feedback_count=Count('feedback'),
        average_rating=Avg('feedback__rating')
    ).values(
        'id', 'title', 'registration_count', 'attendance_count',
        'feedback_count', 'average_rating'
    ).order_by('-registration_count')

    return list(events)

@app.get("/reports/events", response_model=List[dict])
async def get_event_reports(current_user: CustomUser = Depends(get_current_user)):
    """Get event popularity reports"""
    return await get_event_reports_sync(current_user)

@sync_to_async
def get_student_report_sync(student_id: int, current_user: CustomUser):
    """Get student participation report"""
    if not current_user.is_staff and current_user.id != student_id:
        raise HTTPException(status_code=403, detail="Permission denied")

    try:
        from django.db.models import Count, Avg

        student = CustomUser.objects.filter(id=student_id).annotate(
            total_registrations=Count('registrations'),
            total_attendance=Count('attendance'),
            total_feedback=Count('feedback'),
            average_rating_given=Avg('feedback__rating')
        ).values(
            'id', 'name', 'total_registrations', 'total_attendance',
            'total_feedback', 'average_rating_given'
        ).first()

        if not student:
            raise HTTPException(status_code=404, detail="Student not found")

        return student
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/reports/students/{student_id}", response_model=dict)
async def get_student_report(
    student_id: int,
    current_user: CustomUser = Depends(get_current_user)
):
    """Get student participation report"""
    return await get_student_report_sync(student_id, current_user)

@sync_to_async
def get_top_students_sync(current_user: CustomUser):
    """Get top 3 active students"""
    if not current_user.is_staff:
        raise HTTPException(status_code=403, detail="Only staff can access this report")

    from django.db.models import Count

    top_students = CustomUser.objects.annotate(
        participation_score=Count('registrations') + Count('attendance') + Count('feedback'),
        total_registrations=Count('registrations'),
        total_attendance=Count('attendance')
    ).filter(
        participation_score__gt=0
    ).order_by('-participation_score')[:3]

    result = []
    for idx, student in enumerate(top_students, 1):
        result.append({
            'rank': idx,
            'student_id': student.id,
            'name': student.name,
            'participation_score': student.participation_score,
            'total_registrations': student.total_registrations,
            'total_attendance': student.total_attendance
        })

    return result

@app.get("/reports/top-students", response_model=List[dict])
async def get_top_students(current_user: CustomUser = Depends(get_current_user)):
    """Get top 3 active students"""
    return await get_top_students_sync(current_user)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
