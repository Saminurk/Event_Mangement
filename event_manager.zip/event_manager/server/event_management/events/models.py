from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone

class College(models.Model):
    name = models.CharField(max_length=255)
    location = models.CharField(max_length=255)
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = "Colleges"

class CustomUser(AbstractUser):
    name = models.CharField(max_length=150)
    college = models.ForeignKey(College, on_delete=models.CASCADE, related_name='students', null=True, blank=True)
    roll_no = models.CharField(max_length=50, unique=True, null=True, blank=True)
    department = models.CharField(max_length=150)
    email = models.EmailField(max_length=255, unique=True)
    date_of_birth = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.username

class Event(models.Model):
    EVENT_TYPES = [
        ('workshop', 'Workshop'),
        ('fest', 'Fest'),
        ('hackathon', 'Hackathon'),
        ('seminar', 'Seminar'),
    ]

    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('published', 'Published'),
        ('cancelled', 'Cancelled'),
        ('completed', 'Completed'),
    ]

    title = models.CharField(max_length=255)
    description = models.TextField()
    event_type = models.CharField(max_length=20, choices=EVENT_TYPES)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    college = models.ForeignKey(College, on_delete=models.CASCADE, related_name='events')
    created_by = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='created_events')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.title

class Registration(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name='registrations')
    student = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='registrations')
    registered_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.student.name} - {self.event.title}"

    class Meta:
        unique_together = ('event', 'student')

class Attendance(models.Model):
    STATUS_CHOICES = [
        ('present', 'Present'),
        ('absent', 'Absent'),
        ('late', 'Late'),
    ]

    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name='attendance')
    student = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='attendance')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES)
    marked_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.student.name} - {self.event.title} - {self.status}"

    class Meta:
        unique_together = ('event', 'student')

class Feedback(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name='feedback')
    student = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='feedback')
    rating = models.IntegerField(choices=[(i, i) for i in range(1, 6)])  # 1-5 rating
    comments = models.TextField(blank=True)
    submitted_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.student.name} - {self.event.title} - {self.rating}"

    class Meta:
        unique_together = ('event', 'student')
