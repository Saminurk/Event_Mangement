from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser, College, Event, Registration, Attendance, Feedback

@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    model = CustomUser
    fieldsets = UserAdmin.fieldsets + (
        ("College Info", {"fields": ("name", "college", "roll_no", "department", "date_of_birth")}),
    )
    add_fieldsets = UserAdmin.add_fieldsets + (
        ("College Info", {"fields": ("name", "college", "roll_no", "department", "date_of_birth")}),
    )
    list_display = ("username", "email", "name", "college", "roll_no", "department", "is_staff")
    search_fields = ("username", "email", "college__name", "roll_no", "department")

@admin.register(College)
class CollegeAdmin(admin.ModelAdmin):
    list_display = ("name", "location", "created_at")
    search_fields = ("name", "location")

@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ("title", "event_type", "start_time", "end_time", "college", "created_by", "status", "created_at")
    list_filter = ("event_type", "status", "college")
    search_fields = ("title", "description", "college__name", "created_by__username")

@admin.register(Registration)
class RegistrationAdmin(admin.ModelAdmin):
    list_display = ("event", "student", "registered_at")
    list_filter = ("event",)
    search_fields = ("event__title", "student__username")

@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ("event", "student", "status", "marked_at")
    list_filter = ("status", "event")
    search_fields = ("event__title", "student__username")

@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ("event", "student", "rating", "submitted_at")
    list_filter = ("rating", "event")
    search_fields = ("event__title", "student__username")
