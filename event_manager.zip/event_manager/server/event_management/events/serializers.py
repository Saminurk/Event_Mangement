from rest_framework import serializers
from django.contrib.auth import authenticate
from .models import College, CustomUser, Event, Registration, Attendance, Feedback

class CollegeSerializer(serializers.ModelSerializer):
    class Meta:
        model = College
        fields = '__all__'

class CustomUserSerializer(serializers.ModelSerializer):
    college_name = serializers.CharField(source='college.name', read_only=True)

    class Meta:
        model = CustomUser
        fields = ['id', 'username', 'email', 'name', 'college', 'college_name',
                 'roll_no', 'department', 'date_of_birth', 'is_staff', 'is_active']
        extra_kwargs = {
            'password': {'write_only': True}
        }

    def create(self, validated_data):
        user = CustomUser.objects.create_user(**validated_data)
        return user

class LoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField()

    def validate(self, data):
        username = data.get('username')
        password = data.get('password')

        if username and password:
            user = authenticate(username=username, password=password)
            if user:
                if user.is_active:
                    data['user'] = user
                else:
                    raise serializers.ValidationError('User account is disabled.')
            else:
                raise serializers.ValidationError('Unable to log in with provided credentials.')
        else:
            raise serializers.ValidationError('Must include username and password.')

        return data

class EventSerializer(serializers.ModelSerializer):
    college_name = serializers.CharField(source='college.name', read_only=True)
    created_by_name = serializers.CharField(source='created_by.name', read_only=True)
    registration_count = serializers.SerializerMethodField()

    class Meta:
        model = Event
        fields = ['id', 'title', 'description', 'event_type', 'start_time', 'end_time',
                 'college', 'college_name', 'created_by', 'created_by_name', 'status',
                 'created_at', 'registration_count']
        read_only_fields = ['created_by', 'created_at']

    def get_registration_count(self, obj):
        return obj.registrations.count()

    def create(self, validated_data):
        validated_data['created_by'] = self.context['request'].user
        return super().create(validated_data)

class RegistrationSerializer(serializers.ModelSerializer):
    event_title = serializers.CharField(source='event.title', read_only=True)
    student_name = serializers.CharField(source='student.name', read_only=True)

    class Meta:
        model = Registration
        fields = ['id', 'event', 'event_title', 'student', 'student_name', 'registered_at']
        read_only_fields = ['student', 'registered_at']

class AttendanceSerializer(serializers.ModelSerializer):
    event_title = serializers.CharField(source='event.title', read_only=True)
    student_name = serializers.CharField(source='student.name', read_only=True)

    class Meta:
        model = Attendance
        fields = ['id', 'event', 'event_title', 'student', 'student_name', 'status', 'marked_at']
        read_only_fields = ['marked_at']

class FeedbackSerializer(serializers.ModelSerializer):
    event_title = serializers.CharField(source='event.title', read_only=True)
    student_name = serializers.CharField(source='student.name', read_only=True)

    class Meta:
        model = Feedback
        fields = ['id', 'event', 'event_title', 'student', 'student_name', 'rating', 'comments', 'submitted_at']
        read_only_fields = ['student', 'submitted_at']

class StudentRegistrationSerializer(serializers.ModelSerializer):
    """Serializer for student registration (signup)"""
    password = serializers.CharField(write_only=True)

    class Meta:
        model = CustomUser
        fields = ['username', 'password', 'email', 'name', 'college', 'roll_no', 'department', 'date_of_birth']

    def create(self, validated_data):
        user = CustomUser.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            password=validated_data['password'],
            name=validated_data['name'],
            college=validated_data['college'],
            roll_no=validated_data.get('roll_no'),
            department=validated_data['department'],
            date_of_birth=validated_data.get('date_of_birth')
        )
        return user

class EventRegistrationSerializer(serializers.Serializer):
    """Serializer for event registration"""
    event_id = serializers.IntegerField()

    def validate_event_id(self, value):
        try:
            event = Event.objects.get(id=value, status='published')
        except Event.DoesNotExist:
            raise serializers.ValidationError("Event not found or not available for registration.")
        return value

class AttendanceMarkSerializer(serializers.Serializer):
    """Serializer for marking attendance"""
    student_id = serializers.IntegerField()
    status = serializers.ChoiceField(choices=[('present', 'Present'), ('absent', 'Absent'), ('late', 'Late')])

class FeedbackSubmissionSerializer(serializers.Serializer):
    """Serializer for feedback submission"""
    rating = serializers.IntegerField(min_value=1, max_value=5)
    comments = serializers.CharField(required=False, allow_blank=True)

class EventReportSerializer(serializers.Serializer):
    """Serializer for event popularity report"""
    event_id = serializers.IntegerField()
    title = serializers.CharField(read_only=True)
    registration_count = serializers.IntegerField(read_only=True)
    attendance_count = serializers.IntegerField(read_only=True)
    feedback_count = serializers.IntegerField(read_only=True)
    average_rating = serializers.FloatField(read_only=True)

class StudentReportSerializer(serializers.Serializer):
    """Serializer for student participation report"""
    student_id = serializers.IntegerField()
    name = serializers.CharField(read_only=True)
    total_registrations = serializers.IntegerField(read_only=True)
    total_attendance = serializers.IntegerField(read_only=True)
    total_feedback = serializers.IntegerField(read_only=True)
    average_rating_given = serializers.FloatField(read_only=True)

class TopStudentsSerializer(serializers.Serializer):
    """Serializer for top students report"""
    rank = serializers.IntegerField(read_only=True)
    student_id = serializers.IntegerField(read_only=True)
    name = serializers.CharField(read_only=True)
    participation_score = serializers.IntegerField(read_only=True)
    total_registrations = serializers.IntegerField(read_only=True)
    total_attendance = serializers.IntegerField(read_only=True)
