# 🎓 Campus Event Management Platform – Design Document

## 📌 Overview
This platform manages campus events such as *workshops, fests, hackathons, and seminars*.  

- *Admin Portal (Django Admin):* College staff create/manage events and view reports.  
- *Student Interface (React + FastAPI):* Students browse events, register, attend, and submit feedback.  
- *Database (PostgreSQL):* Stores colleges, students, events, registrations, attendance, and feedback.  

---

## 🏗 System Architecture

```mermaid
flowchart TB
    Colleges --> LoadBalancer
    LoadBalancer --> DjangoAdmin
    LoadBalancer --> FastAPI

    DjangoAdmin -->|CRUD Events, Reports| DB[(PostgreSQL DB)]
    FastAPI -->|Registrations, Attendance, Feedback| DB

    ReactApp -->|APIs| FastAPI
    Staff -->|UI| DjangoAdmin

erDiagram
    COLLEGES ||--o{ STUDENTS : has
    COLLEGES ||--o{ EVENTS : organizes
    STUDENTS ||--o{ REGISTRATIONS : registers
    EVENTS ||--o{ REGISTRATIONS : has
    STUDENTS ||--o{ ATTENDANCE : attends
    EVENTS ||--o{ ATTENDANCE : tracks
    STUDENTS ||--o{ FEEDBACK : gives
    EVENTS ||--o{ FEEDBACK : receives

    COLLEGES {
        int id PK
        string name
        string location
        datetime created_at
    }

    STUDENTS {
        int id PK
        int college_id FK
        string name
        string email
        string roll_no
        datetime created_at
    }

    EVENTS {
        int id PK
        int college_id FK
        string title
        string description
        string event_type
        datetime start_time
        datetime end_time
        int created_by
        string status
        datetime created_at
    }

    REGISTRATIONS {
        int id PK
        int event_id FK
        int student_id FK
        datetime registered_at
    }

    ATTENDANCE {
        int id PK
        int event_id FK
        int student_id FK
        string status
        datetime marked_at
    }

    FEEDBACK {
        int id PK
        int event_id FK
        int student_id FK
        int rating
        string comments
        datetime submitted_at
    }

sequenceDiagram
    participant Staff
    participant DjangoAdmin
    participant DB
    participant FastAPI
    participant ReactApp

    Staff->>DjangoAdmin: Create Event
    DjangoAdmin->>DB: Insert Event Record
    ReactApp->>FastAPI: GET /events
    FastAPI->>DB: Fetch Events
    DB-->>FastAPI: Event List
    FastAPI-->>ReactApp: Show Event List


sequenceDiagram
    participant Student
    participant ReactApp
    participant FastAPI
    participant DB

    Student->>ReactApp: Register for Event
    ReactApp->>FastAPI: POST /events/{id}/register
    FastAPI->>DB: Insert Registration
    DB-->>FastAPI: Success
    FastAPI-->>ReactApp: Confirmation

sequenceDiagram
    participant Student
    participant FastAPI
    participant DB

    Student->>FastAPI: POST /events/{id}/attendance
    FastAPI->>DB: Insert Attendance Record
    DB-->>FastAPI: Success
    FastAPI-->>Student: Attendance Marked


sequenceDiagram
    participant Student
    participant ReactApp
    participant FastAPI
    participant DB

    Student->>ReactApp: Submit Feedback
    ReactApp->>FastAPI: POST /events/{id}/feedback
    FastAPI->>DB: Insert Feedback Record
    DB-->>FastAPI: Success
    FastAPI-->>ReactApp: Acknowledgement


sequenceDiagram
    participant Staff
    participant DjangoAdmin
    participant DB

    Staff->>DjangoAdmin: Request Reports
    DjangoAdmin->>DB: Run Queries
    DB-->>DjangoAdmin: Report Data
    DjangoAdmin-->>Staff: Display Report


| Endpoint                  | Method | Description                      |
| ------------------------- | ------ | -------------------------------- |
| /students               | POST   | Register student profile         |
| /events                 | GET    | List all active events           |
| /events/{id}            | GET    | Event details                    |
| /events/{id}/register   | POST   | Register student for event       |
| /events/{id}/attendance | POST   | Mark attendance                  |
| /events/{id}/feedback   | POST   | Submit feedback                  |
| /reports/events         | GET    | Event popularity (registrations) |
| /reports/students/{id}  | GET    | Student participation report     |
| /reports/top-students   | GET    | Top 3 active students            |