# 🎓 Campus Event Management API Documentation

## 📋 Overview
This document provides comprehensive documentation for the FastAPI backend endpoints used in the Campus Event Management Platform. All endpoints require JWT authentication except for student registration and login.

**Base URL:** `http://localhost:8001`  
**Authentication:** JWT Bearer Token  
**Content-Type:** `application/json`

---

## 🔐 Authentication

### JWT Token Format
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer"
}
```

### Headers
```http
Authorization: Bearer <access_token>
```

---

## 📝 API Endpoints

### 1. Student Registration
**Endpoint:** `POST /students`  
**Description:** Register a new student account  
**Authentication:** Not required

#### Request Body
```json
{
  "username": "string",
  "email": "user@example.com",
  "name": "string",
  "college_id": 1,
  "roll_no": "string (optional)",
  "department": "string",
  "date_of_birth": "YYYY-MM-DDTHH:mm:ss (optional)",
  "password": "string"
}
```

#### Response (201 Created)
```json
{
  "message": "Student registered successfully",
  "user": {
    "id": 1,
    "username": "student_username",
    "email": "user@example.com",
    "name": "Student Name",
    "college": "College Name",
    "roll_no": "ROLL123",
    "department": "Computer Science"
  },
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer"
}
```

#### Error Responses
- `400 Bad Request`: Username/email already exists, College not found
- `500 Internal Server Error`: Server error

---

### 2. Student Login
**Endpoint:** `POST /auth/login`  
**Description:** Authenticate student login  
**Authentication:** Not required

#### Request Body
```json
{
  "username": "string",
  "password": "string"
}
```

#### Response (200 OK)
```json
{
  "message": "Login successful",
  "user": {
    "id": 1,
    "username": "student_username",
    "email": "user@example.com",
    "name": "Student Name",
    "college": "College Name",
    "roll_no": "ROLL123",
    "department": "Computer Science"
  },
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer"
}
```

#### Error Responses
- `401 Unauthorized`: Invalid credentials, Account disabled

---

### 3. Get Events
**Endpoint:** `GET /events`  
**Description:** Retrieve all active (published) events  
**Authentication:** Required

#### Query Parameters
- `event_type` (optional): Filter by event type (`workshop`, `fest`, `hackathon`, `seminar`)
- `college_id` (optional): Filter by college ID

#### Example Request
```http
GET /events?event_type=workshop&college_id=1
Authorization: Bearer <token>
```

#### Response (200 OK)
```json
[
  {
    "id": 1,
    "title": "Python Workshop",
    "description": "Learn Python programming",
    "event_type": "workshop",
    "start_time": "2024-01-15T10:00:00",
    "end_time": "2024-01-15T16:00:00",
    "college_id": 1,
    "college_name": "ABC College",
    "created_by_name": "Admin User",
    "status": "published",
    "created_at": "2024-01-10T09:00:00",
    "registration_count": 25
  }
]
```

#### Error Responses
- `401 Unauthorized`: Invalid or missing token

---

### 4. Get Event Details
**Endpoint:** `GET /events/{event_id}`  
**Description:** Get detailed information about a specific event  
**Authentication:** Required

#### Path Parameters
- `event_id`: Integer ID of the event

#### Example Request
```http
GET /events/1
Authorization: Bearer <token>
```

#### Response (200 OK)
```json
{
  "id": 1,
  "title": "Python Workshop",
  "description": "Learn Python programming",
  "event_type": "workshop",
  "start_time": "2024-01-15T10:00:00",
  "end_time": "2024-01-15T16:00:00",
  "college_id": 1,
  "college_name": "ABC College",
  "created_by_name": "Admin User",
  "status": "published",
  "created_at": "2024-01-10T09:00:00",
  "registration_count": 25
}
```

#### Error Responses
- `401 Unauthorized`: Invalid or missing token
- `404 Not Found`: Event not found

---

### 5. Register for Event
**Endpoint:** `POST /events/{event_id}/register`  
**Description:** Register the authenticated student for an event  
**Authentication:** Required

#### Path Parameters
- `event_id`: Integer ID of the event

#### Request Body
*Empty body required*

#### Example Request
```http
POST /events/1/register
Authorization: Bearer <token>
Content-Type: application/json

{}
```

#### Response (201 Created)
```json
{
  "message": "Successfully registered for event",
  "registration": {
    "id": 1,
    "event_title": "Python Workshop",
    "registered_at": "2024-01-12T14:30:00"
  }
}
```

#### Error Responses
- `400 Bad Request`: Already registered, Event has started
- `401 Unauthorized`: Invalid or missing token
- `404 Not Found`: Event not found

---

### 6. Get Student Registrations
**Endpoint:** `GET /students/registrations`  
**Description:** Get all events the authenticated student is registered for  
**Authentication:** Required

#### Response (200 OK)
```json
[
  {
    "id": 1,
    "event_id": 1,
    "event_title": "Python Workshop",
    "registered_at": "2024-01-12T14:30:00"
  },
  {
    "id": 2,
    "event_id": 2,
    "event_title": "Hackathon 2024",
    "registered_at": "2024-01-13T10:15:00"
  }
]
```

#### Error Responses
- `401 Unauthorized`: Invalid or missing token

---

### 7. Mark Attendance
**Endpoint:** `POST /events/{event_id}/attendance`  
**Description:** Mark attendance for a student (Staff only)  
**Authentication:** Required (Staff/Admin only)

#### Path Parameters
- `event_id`: Integer ID of the event

#### Request Body
```json
{
  "student_id": 1,
  "status": "present"
}
```

**Status Options:** `present`, `absent`, `late`

#### Example Request
```http
POST /events/1/attendance
Authorization: Bearer <token>
Content-Type: application/json

{
  "student_id": 1,
  "status": "present"
}
```

#### Response (200 OK)
```json
{
  "message": "Attendance marked successfully",
  "attendance": {
    "id": 1,
    "event_title": "Python Workshop",
    "student_name": "John Doe",
    "status": "present",
    "marked_at": "2024-01-15T10:30:00"
  }
}
```

#### Error Responses
- `400 Bad Request`: Student not registered for event
- `401 Unauthorized`: Invalid token
- `403 Forbidden`: Not a staff member
- `404 Not Found`: Event or student not found

---

### 8. Submit Feedback
**Endpoint:** `POST /events/{event_id}/feedback`  
**Description:** Submit feedback for an attended event  
**Authentication:** Required

#### Path Parameters
- `event_id`: Integer ID of the event

#### Request Body
```json
{
  "rating": 5,
  "comments": "Excellent workshop! Learned a lot."
}
```

**Rating:** Integer from 1-5  
**Comments:** Optional string

#### Example Request
```http
POST /events/1/feedback
Authorization: Bearer <token>
Content-Type: application/json

{
  "rating": 5,
  "comments": "Excellent workshop! Learned a lot."
}
```

#### Response (200 OK)
```json
{
  "message": "Feedback submitted successfully",
  "feedback": {
    "id": 1,
    "event_title": "Python Workshop",
    "rating": 5,
    "comments": "Excellent workshop! Learned a lot.",
    "submitted_at": "2024-01-15T17:00:00"
  }
}
```

#### Error Responses
- `400 Bad Request`: Must attend event to submit feedback
- `401 Unauthorized`: Invalid or missing token
- `404 Not Found`: Event not found

---

### 9. Get Student Feedback
**Endpoint:** `GET /students/feedback`  
**Description:** Get all feedback submitted by the authenticated student  
**Authentication:** Required

#### Response (200 OK)
```json
[
  {
    "id": 1,
    "event_id": 1,
    "event_title": "Python Workshop",
    "rating": 5,
    "comments": "Excellent workshop! Learned a lot.",
    "submitted_at": "2024-01-15T17:00:00"
  }
]
```

#### Error Responses
- `401 Unauthorized`: Invalid or missing token

---

### 10. Get Colleges
**Endpoint:** `GET /colleges`  
**Description:** Get list of all colleges  
**Authentication:** Required

#### Response (200 OK)
```json
[
  {
    "id": 1,
    "name": "ABC College",
    "location": "New York"
  },
  {
    "id": 2,
    "name": "XYZ University",
    "location": "California"
  }
]
```

#### Error Responses
- `401 Unauthorized`: Invalid or missing token

---

### 11. Get Event Reports
**Endpoint:** `GET /reports/events`  
**Description:** Get event popularity and statistics reports (Staff only)  
**Authentication:** Required (Staff/Admin only)

#### Response (200 OK)
```json
[
  {
    "id": 1,
    "title": "Python Workshop",
    "registration_count": 25,
    "attendance_count": 22,
    "feedback_count": 20,
    "average_rating": 4.5
  }
]
```

#### Error Responses
- `401 Unauthorized`: Invalid token
- `403 Forbidden`: Not a staff member

---

### 12. Get Student Report
**Endpoint:** `GET /reports/students/{student_id}`  
**Description:** Get participation report for a specific student  
**Authentication:** Required

#### Path Parameters
- `student_id`: Integer ID of the student

#### Permissions
- Staff/Admin: Can view any student's report
- Students: Can only view their own report

#### Response (200 OK)
```json
{
  "id": 1,
  "name": "John Doe",
  "total_registrations": 5,
  "total_attendance": 4,
  "total_feedback": 3,
  "average_rating_given": 4.2
}
```

#### Error Responses
- `401 Unauthorized`: Invalid token
- `403 Forbidden`: Permission denied
- `404 Not Found`: Student not found

---

### 13. Get Top Students
**Endpoint:** `GET /reports/top-students`  
**Description:** Get top 3 most active students (Staff only)  
**Authentication:** Required (Staff/Admin only)

#### Response (200 OK)
```json
[
  {
    "rank": 1,
    "student_id": 1,
    "name": "John Doe",
    "participation_score": 12,
    "total_registrations": 5,
    "total_attendance": 4
  },
  {
    "rank": 2,
    "student_id": 2,
    "name": "Jane Smith",
    "participation_score": 10,
    "total_registrations": 4,
    "total_attendance": 3
  }
]
```

#### Error Responses
- `401 Unauthorized`: Invalid token
- `403 Forbidden`: Not a staff member

---

## 📊 Data Models

### Pydantic Models Used

#### UserBase
```python
{
  "username": "string",
  "email": "EmailStr",
  "name": "string",
  "college_id": "int",
  "roll_no": "Optional[str]",
  "department": "string",
  "date_of_birth": "Optional[datetime]"
}
```

#### EventBase
```python
{
  "title": "string",
  "description": "string",
  "event_type": "string",
  "start_time": "datetime",
  "end_time": "datetime",
  "college_id": "int"
}
```

#### AttendanceBase
```python
{
  "student_id": "int",
  "status": "string"  # "present" | "absent" | "late"
}
```

#### FeedbackBase
```python
{
  "rating": "int",  # 1-5
  "comments": "Optional[str]"
}
```

---

## 🚨 Error Response Format

All error responses follow this format:
```json
{
  "detail": "Error message description"
}
```

### Common HTTP Status Codes
- `200 OK`: Successful request
- `201 Created`: Resource created successfully
- `400 Bad Request`: Invalid request data
- `401 Unauthorized`: Authentication required or invalid token
- `403 Forbidden`: Insufficient permissions
- `404 Not Found`: Resource not found
- `500 Internal Server Error`: Server error

---

## 🔧 Development Notes

### CORS Configuration
The API allows requests from:
- `http://localhost:3000`
- `http://127.0.0.1:3000`

### JWT Configuration
- **Algorithm**: HS256
- **Token Expiration**: 30 minutes
- **Secret Key**: Configured for development (should be changed in production)

### Database Integration
- Uses Django ORM models
- Asynchronous operations with `@sync_to_async` decorator
- SQLite database (configured in Django settings)

---

## 🧪 Testing Examples

### Register Student
```bash
curl -X POST "http://localhost:8001/students" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "test_student",
    "email": "test@example.com",
    "name": "Test Student",
    "college_id": 1,
    "department": "Computer Science",
    "password": "password123"
  }'
```

### Get Events
```bash
curl -X GET "http://localhost:8001/events" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

### Register for Event
```bash
curl -X POST "http://localhost:8001/events/1/register" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{}'
```

---

*This API documentation is auto-generated from the FastAPI application code and provides all necessary information for frontend integration.*
