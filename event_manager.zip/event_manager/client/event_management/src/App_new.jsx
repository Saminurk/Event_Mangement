import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { ConfigProvider } from 'antd'
import enUS from 'antd/locale/en_US'
import { AuthProvider } from './context/AuthContext'
import LoginPage from './pages/auth/LoginPage'
import StudentDashboard from './pages/student/StudentDashboard'
import AdminDashboard from './pages/admin/AdminDashboard'
import ProtectedRoute from './components/common/ProtectedRoute'

const App = () => {
  return (
    <ConfigProvider locale={enUS} componentSize="middle">
      <AuthProvider>
        <Routes>
          <Route path="/test" element={<div style={{ padding: '20px', textAlign: 'center' }}><h1>Test Page</h1><p>If you can see this, routing is working!</p></div>} />
          <Route path="/login" element={<LoginPage />} />
          <Route
            path="/student/*"
            element={
              <ProtectedRoute role="student">
                <StudentDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/*"
            element={
              <ProtectedRoute role="admin">
                <AdminDashboard />
              </ProtectedRoute>
            }
          />
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </AuthProvider>
    </ConfigProvider>
  )
}

export default App
