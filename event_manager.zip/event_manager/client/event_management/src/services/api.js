import axios from 'axios'

const API_BASE_URL = 'http://localhost:8001'

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('access_token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Response interceptor to handle token refresh
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('access_token')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

// Auth API
export const authAPI = {
  login: (credentials) => api.post('/auth/login', credentials),
  register: (userData) => api.post('/students', userData),
}

// Events API
export const eventsAPI = {
  getEvents: (params) => api.get('/events', { params }),
  getEventDetails: (eventId) => api.get(`/events/${eventId}`),
  registerForEvent: (eventId) => api.post(`/events/${eventId}/register`),
  markAttendance: (eventId, data) => api.post(`/events/${eventId}/attendance`, data),
  submitFeedback: (eventId, data) => api.post(`/events/${eventId}/feedback`, data),
}

// Student API
export const studentAPI = {
  getRegistrations: () => api.get('/students/registrations'),
  getFeedback: () => api.get('/students/feedback'),
}

// Colleges API
export const collegesAPI = {
  getColleges: () => api.get('/colleges'),
}

// Reports API
export const reportsAPI = {
  getEventReports: () => api.get('/reports/events'),
  getStudentReport: (studentId) => api.get(`/reports/students/${studentId}`),
  getTopStudents: () => api.get('/reports/top-students'),
}

export default api
