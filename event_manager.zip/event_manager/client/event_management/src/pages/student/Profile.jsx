import React, { useState, useEffect } from 'react'
import {
  Card,
  Typography,
  Form,
  Input,
  Button,
  Avatar,
  Space,
  message,
  Spin,
  Divider,
  Descriptions,
  Tag,
  Row,
  Col
} from 'antd'
import {
  UserOutlined,
  MailOutlined,
  IdcardOutlined,
  TeamOutlined,
  CalendarOutlined,
  EditOutlined,
  SaveOutlined,
  CloseOutlined
} from '@ant-design/icons'
import { useAuth } from '../../context/AuthContext'

const { Title, Text } = Typography
const { TextArea } = Input

const Profile = () => {
  const { user } = useAuth()
  const [loading, setLoading] = useState(false)
  const [editing, setEditing] = useState(false)
  const [form] = Form.useForm()

  useEffect(() => {
    if (user) {
      form.setFieldsValue({
        name: user.name,
        email: user.email,
        roll_no: user.roll_no,
        department: user.department,
        date_of_birth: user.date_of_birth
      })
    }
  }, [user, form])

  const handleEdit = () => {
    setEditing(true)
  }

  const handleCancel = () => {
    form.resetFields()
    setEditing(false)
  }

  const handleSave = async (values) => {
    try {
      setLoading(true)
      // TODO: Implement profile update API call
      message.success('Profile updated successfully!')
      setEditing(false)
    } catch (error) {
      message.error('Failed to update profile')
    } finally {
      setLoading(false)
    }
  }

  if (!user) {
    return (
      <div style={{ textAlign: 'center', padding: '50px' }}>
        <Spin size="large" />
        <div style={{ marginTop: '16px' }}>
          <Text>Loading profile...</Text>
        </div>
      </div>
    )
  }

  return (
    <div>
      <div style={{ marginBottom: '24px' }}>
        <Title level={2}>My Profile</Title>
        <Text type="secondary">
          View and manage your personal information
        </Text>
      </div>

      <Row gutter={[24, 24]}>
        <Col xs={24} lg={8}>
          {/* Profile Avatar Card */}
          <Card style={{ textAlign: 'center' }}>
            <Avatar
              size={120}
              icon={<UserOutlined />}
              style={{ marginBottom: '16px' }}
            />
            <Title level={3}>{user.name}</Title>
            <Text type="secondary">{user.username}</Text>
            <br />
            <Tag color="blue" style={{ marginTop: '8px' }}>
              Student
            </Tag>
          </Card>

          {/* Quick Stats Card */}
          <Card style={{ marginTop: '24px' }}>
            <Title level={4}>Quick Stats</Title>
            <Space direction="vertical" style={{ width: '100%' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <Text>Events Registered:</Text>
                <Text strong>5</Text>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <Text>Events Attended:</Text>
                <Text strong>4</Text>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <Text>Feedback Given:</Text>
                <Text strong>3</Text>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <Text>Participation Score:</Text>
                <Text strong>12</Text>
              </div>
            </Space>
          </Card>
        </Col>

        <Col xs={24} lg={16}>
          {/* Profile Information Card */}
          <Card
            title="Personal Information"
            extra={
              !editing ? (
                <Button
                  type="primary"
                  icon={<EditOutlined />}
                  onClick={handleEdit}
                >
                  Edit Profile
                </Button>
              ) : (
                <Space>
                  <Button
                    type="primary"
                    icon={<SaveOutlined />}
                    onClick={() => form.submit()}
                    loading={loading}
                  >
                    Save
                  </Button>
                  <Button
                    icon={<CloseOutlined />}
                    onClick={handleCancel}
                  >
                    Cancel
                  </Button>
                </Space>
              )
            }
          >
            {editing ? (
              <Form
                form={form}
                layout="vertical"
                onFinish={handleSave}
              >
                <Form.Item
                  name="name"
                  label="Full Name"
                  rules={[{ required: true, message: 'Please enter your name' }]}
                >
                  <Input placeholder="Enter your full name" />
                </Form.Item>

                <Form.Item
                  name="email"
                  label="Email"
                  rules={[
                    { required: true, message: 'Please enter your email' },
                    { type: 'email', message: 'Please enter a valid email' }
                  ]}
                >
                  <Input placeholder="Enter your email" />
                </Form.Item>

                <Form.Item
                  name="roll_no"
                  label="Roll Number"
                >
                  <Input placeholder="Enter your roll number" />
                </Form.Item>

                <Form.Item
                  name="department"
                  label="Department"
                  rules={[{ required: true, message: 'Please enter your department' }]}
                >
                  <Input placeholder="Enter your department" />
                </Form.Item>

                <Form.Item
                  name="date_of_birth"
                  label="Date of Birth"
                >
                  <Input placeholder="YYYY-MM-DD" />
                </Form.Item>
              </Form>
            ) : (
              <Descriptions column={2}>
                <Descriptions.Item label={<Space><UserOutlined />Full Name</Space>}>
                  {user.name}
                </Descriptions.Item>
                <Descriptions.Item label={<Space><MailOutlined />Email</Space>}>
                  {user.email}
                </Descriptions.Item>
                <Descriptions.Item label={<Space><IdcardOutlined />Username</Space>}>
                  {user.username}
                </Descriptions.Item>
                <Descriptions.Item label={<Space><IdcardOutlined />Roll Number</Space>}>
                  {user.roll_no || 'Not provided'}
                </Descriptions.Item>
                <Descriptions.Item label={<Space><TeamOutlined />College</Space>}>
                  {user.college || 'Not assigned'}
                </Descriptions.Item>
                <Descriptions.Item label={<Space><TeamOutlined />Department</Space>}>
                  {user.department}
                </Descriptions.Item>
                <Descriptions.Item label={<Space><CalendarOutlined />Date of Birth</Space>}>
                  {user.date_of_birth || 'Not provided'}
                </Descriptions.Item>
                <Descriptions.Item label={<Space><CalendarOutlined />Joined</Space>}>
                  {user.created_at ? new Date(user.created_at).toLocaleDateString() : 'N/A'}
                </Descriptions.Item>
              </Descriptions>
            )}
          </Card>

          {/* Account Security Card */}
          <Card style={{ marginTop: '24px' }}>
            <Title level={4}>Account Security</Title>
            <Space direction="vertical" style={{ width: '100%' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <Text strong>Password</Text>
                  <br />
                  <Text type="secondary">Last changed 30 days ago</Text>
                </div>
                <Button type="link">Change Password</Button>
              </div>
              <Divider />
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <Text strong>Two-Factor Authentication</Text>
                  <br />
                  <Text type="secondary">Not enabled</Text>
                </div>
                <Button type="link">Enable 2FA</Button>
              </div>
            </Space>
          </Card>
        </Col>
      </Row>
    </div>
  )
}

export default Profile
