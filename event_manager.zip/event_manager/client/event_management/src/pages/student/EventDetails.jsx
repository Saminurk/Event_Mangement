import React, { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import {
  Card,
  Typography,
  Button,
  Space,
  Tag,
  Descriptions,
  message,
  Spin,
  Modal,
  Form,
  Rate,
  Input,
  Row,
  Col
} from 'antd'
import {
  CalendarOutlined,
  ClockCircleOutlined,
  UserOutlined,
  TeamOutlined,
  EnvironmentOutlined,
  CheckCircleOutlined,
  StarOutlined
} from '@ant-design/icons'
import { eventsAPI } from '../../services/api'
import dayjs from 'dayjs'

const { Title, Text, Paragraph } = Typography
const { TextArea } = Input

const EventDetails = () => {
  const { eventId } = useParams()
  const navigate = useNavigate()
  const [event, setEvent] = useState(null)
  const [loading, setLoading] = useState(true)
  const [registering, setRegistering] = useState(false)
  const [isRegistered, setIsRegistered] = useState(false)
  const [feedbackModalVisible, setFeedbackModalVisible] = useState(false)
  const [feedbackForm] = Form.useForm()

  useEffect(() => {
    fetchEventDetails()
  }, [eventId])

  const fetchEventDetails = async () => {
    try {
      setLoading(true)
      const response = await eventsAPI.getEventDetails(eventId)
      setEvent(response.data)
      // TODO: Check if user is already registered
    } catch (error) {
      message.error('Failed to load event details')
      console.error('Error fetching event details:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleRegister = async () => {
    try {
      setRegistering(true)
      await eventsAPI.registerForEvent(eventId)
      message.success('Successfully registered for the event!')
      setIsRegistered(true)
      // Refresh event details to update registration count
      fetchEventDetails()
    } catch (error) {
      const errorMessage = error.response?.data?.detail || 'Registration failed'
      message.error(errorMessage)
    } finally {
      setRegistering(false)
    }
  }

  const handleFeedbackSubmit = async (values) => {
    try {
      await eventsAPI.submitFeedback(eventId, values)
      message.success('Feedback submitted successfully!')
      setFeedbackModalVisible(false)
      feedbackForm.resetFields()
    } catch (error) {
      const errorMessage = error.response?.data?.detail || 'Failed to submit feedback'
      message.error(errorMessage)
    }
  }

  const getEventTypeColor = (eventType) => {
    const colors = {
      workshop: 'blue',
      fest: 'purple',
      hackathon: 'green',
      seminar: 'orange'
    }
    return colors[eventType] || 'default'
  }

  const formatDateTime = (dateTime) => {
    return dayjs(dateTime).format('dddd, MMMM DD, YYYY')
  }

  const formatTime = (dateTime) => {
    return dayjs(dateTime).format('hh:mm A')
  }

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '50px' }}>
        <Spin size="large" />
        <div style={{ marginTop: '16px' }}>
          <Text>Loading event details...</Text>
        </div>
      </div>
    )
  }

  if (!event) {
    return (
      <div style={{ textAlign: 'center', padding: '50px' }}>
        <Text type="danger">Event not found</Text>
      </div>
    )
  }

  const isEventStarted = dayjs().isAfter(dayjs(event.start_time))
  const isEventEnded = dayjs().isAfter(dayjs(event.end_time))

  return (
    <div>
      {/* Event Header */}
      <Card style={{ marginBottom: '24px' }}>
        <div style={{ textAlign: 'center', marginBottom: '24px' }}>
          <Title level={1} style={{ marginBottom: '8px' }}>
            {event.title}
          </Title>
          <Space>
            <Tag color={getEventTypeColor(event.event_type)} size="large">
              {event.event_type.toUpperCase()}
            </Tag>
            <Tag color={event.status === 'published' ? 'green' : 'orange'}>
              {event.status.toUpperCase()}
            </Tag>
          </Space>
        </div>

        <Row gutter={[24, 24]}>
          <Col xs={24} lg={16}>
            <Paragraph style={{ fontSize: '16px', lineHeight: '1.6' }}>
              {event.description}
            </Paragraph>
          </Col>

          <Col xs={24} lg={8}>
            <Card size="small" style={{ marginBottom: '16px' }}>
              <Space direction="vertical" size={12} style={{ width: '100%' }}>
                <Space>
                  <CalendarOutlined />
                  <div>
                    <Text strong>Date</Text>
                    <br />
                    <Text>{formatDateTime(event.start_time)}</Text>
                  </div>
                </Space>

                <Space>
                  <ClockCircleOutlined />
                  <div>
                    <Text strong>Time</Text>
                    <br />
                    <Text>
                      {formatTime(event.start_time)} - {formatTime(event.end_time)}
                    </Text>
                  </div>
                </Space>

                <Space>
                  <EnvironmentOutlined />
                  <div>
                    <Text strong>College</Text>
                    <br />
                    <Text>{event.college_name}</Text>
                  </div>
                </Space>

                <Space>
                  <UserOutlined />
                  <div>
                    <Text strong>Organizer</Text>
                    <br />
                    <Text>{event.created_by_name}</Text>
                  </div>
                </Space>

                <Space>
                  <TeamOutlined />
                  <div>
                    <Text strong>Registrations</Text>
                    <br />
                    <Text>{event.registration_count} students</Text>
                  </div>
                </Space>
              </Space>
            </Card>

            {/* Action Buttons */}
            <Space direction="vertical" style={{ width: '100%' }}>
              {!isRegistered ? (
                <Button
                  type="primary"
                  size="large"
                  block
                  onClick={handleRegister}
                  loading={registering}
                  disabled={isEventStarted}
                  icon={<CheckCircleOutlined />}
                >
                  {isEventStarted ? 'Event Started' : 'Register for Event'}
                </Button>
              ) : (
                <Button
                  type="default"
                  size="large"
                  block
                  disabled
                  icon={<CheckCircleOutlined />}
                >
                  Already Registered
                </Button>
              )}

              {isRegistered && isEventEnded && (
                <Button
                  type="default"
                  size="large"
                  block
                  onClick={() => setFeedbackModalVisible(true)}
                  icon={<StarOutlined />}
                >
                  Submit Feedback
                </Button>
              )}

              <Button
                size="large"
                block
                onClick={() => navigate('/student/events')}
              >
                Back to Events
              </Button>
            </Space>
          </Col>
        </Row>
      </Card>

      {/* Feedback Modal */}
      <Modal
        title="Submit Feedback"
        open={feedbackModalVisible}
        onCancel={() => setFeedbackModalVisible(false)}
        footer={null}
      >
        <Form
          form={feedbackForm}
          layout="vertical"
          onFinish={handleFeedbackSubmit}
        >
          <Form.Item
            name="rating"
            label="Rating"
            rules={[{ required: true, message: 'Please provide a rating' }]}
          >
            <Rate />
          </Form.Item>

          <Form.Item
            name="comments"
            label="Comments"
            rules={[{ required: true, message: 'Please provide feedback comments' }]}
          >
            <TextArea
              rows={4}
              placeholder="Share your experience and suggestions..."
            />
          </Form.Item>

          <Form.Item style={{ textAlign: 'right', marginBottom: 0 }}>
            <Space>
              <Button onClick={() => setFeedbackModalVisible(false)}>
                Cancel
              </Button>
              <Button type="primary" htmlType="submit">
                Submit Feedback
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  )
}

export default EventDetails
