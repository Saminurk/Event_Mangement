import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Card,
  Row,
  Col,
  Select,
  Input,
  Button,
  Typography,
  Tag,
  Space,
  Empty,
  Spin,
  message
} from 'antd'
import {
  SearchOutlined,
  FilterOutlined,
  CalendarOutlined,
  UserOutlined,
  TeamOutlined
} from '@ant-design/icons'
import { eventsAPI, collegesAPI } from '../../services/api'
import dayjs from 'dayjs'

const { Title, Text, Paragraph } = Typography
const { Option } = Select
const { Meta } = Card

const EventList = () => {
  const [events, setEvents] = useState([])
  const [loading, setLoading] = useState(true)
  const [colleges, setColleges] = useState([])
  const [filters, setFilters] = useState({
    event_type: '',
    college_id: '',
    search: ''
  })
  const navigate = useNavigate()

  useEffect(() => {
    fetchEvents()
    fetchColleges()
  }, [filters])

  const fetchEvents = async () => {
    try {
      setLoading(true)
      const params = {}
      if (filters.event_type) params.event_type = filters.event_type
      if (filters.college_id) params.college_id = filters.college_id

      const response = await eventsAPI.getEvents(params)
      let filteredEvents = response.data

      // Client-side search filter
      if (filters.search) {
        filteredEvents = filteredEvents.filter(event =>
          event.title.toLowerCase().includes(filters.search.toLowerCase()) ||
          event.description.toLowerCase().includes(filters.search.toLowerCase())
        )
      }

      setEvents(filteredEvents)
    } catch (error) {
      message.error('Failed to load events')
      console.error('Error fetching events:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchColleges = async () => {
    try {
      const response = await collegesAPI.getColleges()
      setColleges(response.data)
    } catch (error) {
      console.error('Error fetching colleges:', error)
    }
  }

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }))
  }

  const handleViewEvent = (eventId) => {
    navigate(`/student/events/${eventId}`)
  }

  const getEventTypeColor = (eventType) => {
    const colors = {
      workshop: 'blue',
      fest: 'purple',
      hackathon: 'green',
      seminar: 'orange'
    }
    return colors[eventType] || 'default'
  }

  const formatDateTime = (dateTime) => {
    return dayjs(dateTime).format('MMM DD, YYYY hh:mm A')
  }

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '50px' }}>
        <Spin size="large" />
        <div style={{ marginTop: '16px' }}>
          <Text>Loading events...</Text>
        </div>
      </div>
    )
  }

  return (
    <div>
      <div style={{ marginBottom: '24px' }}>
        <Title level={2}>Browse Events</Title>
        <Text type="secondary">
          Discover and register for upcoming campus events
        </Text>
      </div>

      {/* Filters */}
      <Card style={{ marginBottom: '24px' }}>
        <Row gutter={[16, 16]} align="middle">
          <Col xs={24} sm={12} md={6}>
            <Input
              placeholder="Search events..."
              prefix={<SearchOutlined />}
              value={filters.search}
              onChange={(e) => handleFilterChange('search', e.target.value)}
              allowClear
            />
          </Col>

          <Col xs={24} sm={12} md={6}>
            <Select
              placeholder="Event Type"
              style={{ width: '100%' }}
              value={filters.event_type}
              onChange={(value) => handleFilterChange('event_type', value)}
              allowClear
            >
              <Option value="workshop">Workshop</Option>
              <Option value="fest">Fest</Option>
              <Option value="hackathon">Hackathon</Option>
              <Option value="seminar">Seminar</Option>
            </Select>
          </Col>

          <Col xs={24} sm={12} md={6}>
            <Select
              placeholder="College"
              style={{ width: '100%' }}
              value={filters.college_id}
              onChange={(value) => handleFilterChange('college_id', value)}
              allowClear
            >
              {colleges.map(college => (
                <Option key={college.id} value={college.id}>
                  {college.name}
                </Option>
              ))}
            </Select>
          </Col>

          <Col xs={24} sm={12} md={6}>
            <Button
              icon={<FilterOutlined />}
              onClick={() => setFilters({ event_type: '', college_id: '', search: '' })}
              block
            >
              Clear Filters
            </Button>
          </Col>
        </Row>
      </Card>

      {/* Events Grid */}
      {events.length === 0 ? (
        <Empty
          description="No events found"
          image={Empty.PRESENTED_IMAGE_SIMPLE}
        />
      ) : (
        <Row gutter={[24, 24]}>
          {events.map(event => (
            <Col xs={24} sm={12} lg={8} key={event.id}>
              <Card
                hoverable
                cover={
                  <div style={{
                    height: '160px',
                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: 'white',
                    fontSize: '48px'
                  }}>
                    📅
                  </div>
                }
                actions={[
                  <Button
                    type="primary"
                    onClick={() => handleViewEvent(event.id)}
                    block
                  >
                    View Details
                  </Button>
                ]}
              >
                <Meta
                  title={
                    <Space direction="vertical" size={4}>
                      <Text strong style={{ fontSize: '16px' }}>
                        {event.title}
                      </Text>
                      <Tag color={getEventTypeColor(event.event_type)}>
                        {event.event_type.toUpperCase()}
                      </Tag>
                    </Space>
                  }
                  description={
                    <Space direction="vertical" size={8}>
                      <Paragraph
                        ellipsis={{ rows: 2, expandable: false }}
                        style={{ margin: 0, color: '#666' }}
                      >
                        {event.description}
                      </Paragraph>

                      <Space direction="vertical" size={4}>
                        <Space>
                          <CalendarOutlined />
                          <Text type="secondary" style={{ fontSize: '12px' }}>
                            {formatDateTime(event.start_time)}
                          </Text>
                        </Space>

                        <Space>
                          <UserOutlined />
                          <Text type="secondary" style={{ fontSize: '12px' }}>
                            {event.created_by_name}
                          </Text>
                        </Space>

                        <Space>
                          <TeamOutlined />
                          <Text type="secondary" style={{ fontSize: '12px' }}>
                            {event.registration_count} registered
                          </Text>
                        </Space>
                      </Space>
                    </Space>
                  }
                />
              </Card>
            </Col>
          ))}
        </Row>
      )}
    </div>
  )
}

export default EventList
