import React from 'react'
import { Routes, Route } from 'react-router-dom'
import { Layout, Menu, Avatar, Dropdown, Typography, Space } from 'antd'
import {
  DashboardOutlined,
  CalendarOutlined,
  UserOutlined,
  LogoutOutlined,
  CheckCircleOutlined
} from '@ant-design/icons'
import { useAuth } from '../../context/AuthContext'
import { useNavigate, useLocation } from 'react-router-dom'
import EventList from './EventList'
import EventDetails from './EventDetails'
import MyEvents from './MyEvents'
import Profile from './Profile'

const { Header, Sider, Content } = Layout
const { Text } = Typography

const StudentDashboard = () => {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [collapsed, setCollapsed] = React.useState(false)

  const menuItems = [
    {
      key: '/student',
      icon: <DashboardOutlined />,
      label: 'Dashboard',
    },
    {
      key: '/student/events',
      icon: <CalendarOutlined />,
      label: 'Browse Events',
    },
    {
      key: '/student/my-events',
      icon: <CheckCircleOutlined />,
      label: 'My Events',
    },
    {
      key: '/student/profile',
      icon: <UserOutlined />,
      label: 'Profile',
    },
  ]

  const handleMenuClick = ({ key }) => {
    navigate(key)
  }

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const userMenuItems = [
    {
      key: 'profile',
      icon: <UserOutlined />,
      label: 'Profile',
      onClick: () => navigate('/student/profile'),
    },
    {
      key: 'logout',
      icon: <LogoutOutlined />,
      label: 'Logout',
      onClick: handleLogout,
    },
  ]

  const getSelectedKey = () => {
    const path = location.pathname
    if (path === '/student') return ['/student']
    if (path.startsWith('/student/events')) return ['/student/events']
    if (path.startsWith('/student/my-events')) return ['/student/my-events']
    if (path.startsWith('/student/profile')) return ['/student/profile']
    return ['/student']
  }

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Sider
        collapsible
        collapsed={collapsed}
        onCollapse={setCollapsed}
        theme="dark"
      >
        <div style={{
          height: '64px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: '#001529',
          borderBottom: '1px solid #002140'
        }}>
          <Text style={{ color: 'white', fontSize: '18px', fontWeight: 'bold' }}>
            {collapsed ? '🎓' : 'Campus Events'}
          </Text>
        </div>

        <Menu
          theme="dark"
          mode="inline"
          selectedKeys={getSelectedKey()}
          items={menuItems}
          onClick={handleMenuClick}
        />
      </Sider>

      <Layout>
        <Header style={{
          background: '#fff',
          padding: '0 24px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <Text style={{ fontSize: '18px', fontWeight: 'bold' }}>
            Student Dashboard
          </Text>

          <Space>
            <Text>Welcome, {user?.name || user?.username}</Text>
            <Dropdown
              menu={{ items: userMenuItems }}
              placement="bottomRight"
            >
              <Avatar
                style={{ cursor: 'pointer' }}
                icon={<UserOutlined />}
              />
            </Dropdown>
          </Space>
        </Header>

        <Content style={{
          margin: '24px 16px',
          padding: 24,
          background: '#fff',
          minHeight: 280,
          borderRadius: '8px'
        }}>
          <Routes>
            <Route path="/" element={<EventList />} />
            <Route path="/events" element={<EventList />} />
            <Route path="/events/:eventId" element={<EventDetails />} />
            <Route path="/my-events" element={<MyEvents />} />
            <Route path="/profile" element={<Profile />} />
          </Routes>
        </Content>
      </Layout>
    </Layout>
  )
}

export default StudentDashboard
