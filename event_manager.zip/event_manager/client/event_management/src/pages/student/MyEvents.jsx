import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Card,
  Typography,
  Tabs,
  List,
  Tag,
  Button,
  Empty,
  Spin,
  Space,
  message
} from 'antd'
import {
  CalendarOutlined,
  ClockCircleOutlined,
  EnvironmentOutlined,
  UserOutlined,
  CheckCircleOutlined,
  StarOutlined
} from '@ant-design/icons'
import { studentAPI, eventsAPI } from '../../services/api'
import dayjs from 'dayjs'

const { Title, Text } = Typography
const { TabPane } = Tabs

const MyEvents = () => {
  const navigate = useNavigate()
  const [registrations, setRegistrations] = useState([])
  const [feedback, setFeedback] = useState([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('registered')

  useEffect(() => {
    fetchMyEvents()
  }, [])

  const fetchMyEvents = async () => {
    try {
      setLoading(true)
      const [registrationsResponse, feedbackResponse] = await Promise.all([
        studentAPI.getRegistrations(),
        studentAPI.getFeedback()
      ])

      setRegistrations(registrationsResponse.data)
      setFeedback(feedbackResponse.data)
    } catch (error) {
      message.error('Failed to load your events')
      console.error('Error fetching my events:', error)
    } finally {
      setLoading(false)
    }
  }

  const getEventTypeColor = (eventType) => {
    const colors = {
      workshop: 'blue',
      fest: 'purple',
      hackathon: 'green',
      seminar: 'orange'
    }
    return colors[eventType] || 'default'
  }

  const formatDateTime = (dateTime) => {
    return dayjs(dateTime).format('MMM DD, YYYY hh:mm A')
  }

  const getEventStatus = (startTime, endTime) => {
    const now = dayjs()
    const start = dayjs(startTime)
    const end = dayjs(endTime)

    if (now.isBefore(start)) {
      return { status: 'upcoming', color: 'blue', text: 'Upcoming' }
    } else if (now.isBetween(start, end)) {
      return { status: 'ongoing', color: 'green', text: 'Ongoing' }
    } else {
      return { status: 'completed', color: 'gray', text: 'Completed' }
    }
  }

  const renderEventItem = (item, showFeedback = false) => {
    // Handle different data structures from API
    const eventTitle = item.event_title || item.title || 'Unknown Event'
    const eventId = item.event_id || item.id
    const eventType = item.event_type || 'general'
    const startTime = item.start_time || item.event?.start_time
    const endTime = item.end_time || item.event?.end_time
    const collegeName = item.college_name || item.event?.college_name

    const status = startTime && endTime ? getEventStatus(startTime, endTime) : { status: 'unknown', color: 'default', text: 'Unknown' }

    return (
      <List.Item
        actions={[
          <Button
            type="primary"
            size="small"
            onClick={() => navigate(`/student/events/${eventId}`)}
          >
            View Details
          </Button>
        ]}
      >
        <List.Item.Meta
          title={
            <Space>
              <Text strong>{eventTitle}</Text>
              <Tag color={getEventTypeColor(eventType)}>
                {eventType?.toUpperCase()}
              </Tag>
              <Tag color={status.color}>
                {status.text}
              </Tag>
            </Space>
          }
          description={
            <Space direction="vertical" size={4}>
              {startTime && (
                <Space>
                  <CalendarOutlined />
                  <Text type="secondary" style={{ fontSize: '12px' }}>
                    {formatDateTime(startTime)}
                  </Text>
                </Space>
              )}

              {collegeName && (
                <Space>
                  <EnvironmentOutlined />
                  <Text type="secondary" style={{ fontSize: '12px' }}>
                    {collegeName}
                  </Text>
                </Space>
              )}

              {item.registered_at && (
                <Space>
                  <CheckCircleOutlined />
                  <Text type="secondary" style={{ fontSize: '12px' }}>
                    Registered on {dayjs(item.registered_at).format('MMM DD, YYYY')}
                  </Text>
                </Space>
              )}

              {showFeedback && item.rating && (
                <Space>
                  <StarOutlined />
                  <Text type="secondary" style={{ fontSize: '12px' }}>
                    Rating: {item.rating}/5
                  </Text>
                </Space>
              )}
            </Space>
          }
        />
      </List.Item>
    )
  }

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '50px' }}>
        <Spin size="large" />
        <div style={{ marginTop: '16px' }}>
          <Text>Loading your events...</Text>
        </div>
      </div>
    )
  }

  return (
    <div>
      <div style={{ marginBottom: '24px' }}>
        <Title level={2}>My Events</Title>
        <Text type="secondary">
          Track your event registrations and participation
        </Text>
      </div>

      <Card>
        <Tabs activeKey={activeTab} onChange={setActiveTab}>
          <TabPane
            tab={`Registered Events (${registrations.length})`}
            key="registered"
          >
            {registrations.length === 0 ? (
              <Empty
                description="You haven't registered for any events yet"
                image={Empty.PRESENTED_IMAGE_SIMPLE}
              >
                <Button
                  type="primary"
                  onClick={() => navigate('/student/events')}
                >
                  Browse Events
                </Button>
              </Empty>
            ) : (
              <List
                dataSource={registrations}
                renderItem={(item) => renderEventItem(item)}
                size="large"
              />
            )}
          </TabPane>

          <TabPane
            tab={`Feedback Given (${feedback.length})`}
            key="feedback"
          >
            {feedback.length === 0 ? (
              <Empty
                description="You haven't submitted feedback for any events yet"
                image={Empty.PRESENTED_IMAGE_SIMPLE}
              />
            ) : (
              <List
                dataSource={feedback}
                renderItem={(item) => renderEventItem(item, true)}
                size="large"
              />
            )}
          </TabPane>
        </Tabs>
      </Card>
    </div>
  )
}

export default MyEvents
