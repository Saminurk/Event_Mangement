import React, { useState, useEffect } from 'react'
import {
  Card,
  Typography,
  Button,
  Table,
  Tag,
  Space,
  Modal,
  Form,
  Input,
  Select,
  DatePicker,
  message,
  Popconfirm,
  Spin
} from 'antd'
import {
  PlusOutlined,
  EditOutlined,
  DeleteOutlined,
  EyeOutlined,
  CalendarOutlined,
  TeamOutlined
} from '@ant-design/icons'
import { eventsAPI, collegesAPI } from '../../services/api'
import dayjs from 'dayjs'

const { Title, Text } = Typography
const { TextArea } = Input
const { Option } = Select
const { RangePicker } = DatePicker

const EventManagement = () => {
  const [events, setEvents] = useState([])
  const [colleges, setColleges] = useState([])
  const [loading, setLoading] = useState(true)
  const [modalVisible, setModalVisible] = useState(false)
  const [editingEvent, setEditingEvent] = useState(null)
  const [form] = Form.useForm()

  useEffect(() => {
    fetchEvents()
    fetchColleges()
  }, [])

  const fetchEvents = async () => {
    try {
      setLoading(true)
      const response = await eventsAPI.getEvents()
      setEvents(response.data)
    } catch (error) {
      message.error('Failed to load events')
      console.error('Error fetching events:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchColleges = async () => {
    try {
      const response = await collegesAPI.getColleges()
      setColleges(response.data)
    } catch (error) {
      console.error('Error fetching colleges:', error)
    }
  }

  const handleCreate = () => {
    setEditingEvent(null)
    form.resetFields()
    setModalVisible(true)
  }

  const handleEdit = (event) => {
    setEditingEvent(event)
    form.setFieldsValue({
      ...event,
      dateRange: [dayjs(event.start_time), dayjs(event.end_time)]
    })
    setModalVisible(true)
  }

  const handleDelete = async (eventId) => {
    try {
      // Note: This would require a DELETE endpoint in the backend
      message.success('Event deleted successfully')
      fetchEvents()
    } catch (error) {
      message.error('Failed to delete event')
    }
  }

  const handleSubmit = async (values) => {
    try {
      const eventData = {
        ...values,
        start_time: values.dateRange[0].format('YYYY-MM-DDTHH:mm:ss'),
        end_time: values.dateRange[1].format('YYYY-MM-DDTHH:mm:ss'),
        college_id: values.college_id
      }
      delete eventData.dateRange

      if (editingEvent) {
        // Update event - would need PUT endpoint
        message.success('Event updated successfully')
      } else {
        // Create event - would need POST endpoint
        message.success('Event created successfully')
      }

      setModalVisible(false)
      fetchEvents()
    } catch (error) {
      message.error('Failed to save event')
    }
  }

  const getStatusColor = (status) => {
    const colors = {
      draft: 'orange',
      published: 'green',
      cancelled: 'red',
      completed: 'gray'
    }
    return colors[status] || 'default'
  }

  const getEventTypeColor = (eventType) => {
    const colors = {
      workshop: 'blue',
      fest: 'purple',
      hackathon: 'green',
      seminar: 'orange'
    }
    return colors[eventType] || 'default'
  }

  const columns = [
    {
      title: 'Title',
      dataIndex: 'title',
      key: 'title',
      render: (text, record) => (
        <Space>
          <Text strong>{text}</Text>
          <Tag color={getEventTypeColor(record.event_type)}>
            {record.event_type}
          </Tag>
        </Space>
      )
    },
    {
      title: 'College',
      dataIndex: 'college_name',
      key: 'college_name'
    },
    {
      title: 'Date & Time',
      key: 'datetime',
      render: (_, record) => (
        <Space direction="vertical" size={0}>
          <Text>{dayjs(record.start_time).format('MMM DD, YYYY')}</Text>
          <Text type="secondary" style={{ fontSize: '12px' }}>
            {dayjs(record.start_time).format('hh:mm A')} - {dayjs(record.end_time).format('hh:mm A')}
          </Text>
        </Space>
      )
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status) => (
        <Tag color={getStatusColor(status)}>
          {status.toUpperCase()}
        </Tag>
      )
    },
    {
      title: 'Registrations',
      dataIndex: 'registration_count',
      key: 'registration_count',
      render: (count) => (
        <Space>
          <TeamOutlined />
          <Text>{count}</Text>
        </Space>
      )
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_, record) => (
        <Space>
          <Button
            type="text"
            icon={<EyeOutlined />}
            onClick={() => message.info('View event details')}
          />
          <Button
            type="text"
            icon={<EditOutlined />}
            onClick={() => handleEdit(record)}
          />
          <Popconfirm
            title="Are you sure you want to delete this event?"
            onConfirm={() => handleDelete(record.id)}
            okText="Yes"
            cancelText="No"
          >
            <Button
              type="text"
              danger
              icon={<DeleteOutlined />}
            />
          </Popconfirm>
        </Space>
      )
    }
  ]

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '50px' }}>
        <Spin size="large" />
        <div style={{ marginTop: '16px' }}>
          <Text>Loading events...</Text>
        </div>
      </div>
    )
  }

  return (
    <div>
      <div style={{ marginBottom: '24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <Title level={2}>Event Management</Title>
          <Text type="secondary">
            Create, edit, and manage campus events
          </Text>
        </div>
        <Button
          type="primary"
          icon={<PlusOutlined />}
          onClick={handleCreate}
        >
          Create Event
        </Button>
      </div>

      <Card>
        <Table
          columns={columns}
          dataSource={events}
          rowKey="id"
          pagination={{
            pageSize: 10,
            showSizeChanger: true,
            showQuickJumper: true,
            showTotal: (total, range) =>
              `${range[0]}-${range[1]} of ${total} events`
          }}
        />
      </Card>

      {/* Event Modal */}
      <Modal
        title={editingEvent ? 'Edit Event' : 'Create Event'}
        open={modalVisible}
        onCancel={() => setModalVisible(false)}
        footer={null}
        width={600}
      >
        <Form
          form={form}
          layout="vertical"
          onFinish={handleSubmit}
        >
          <Form.Item
            name="title"
            label="Event Title"
            rules={[{ required: true, message: 'Please enter event title' }]}
          >
            <Input placeholder="Enter event title" />
          </Form.Item>

          <Form.Item
            name="description"
            label="Description"
            rules={[{ required: true, message: 'Please enter event description' }]}
          >
            <TextArea
              rows={4}
              placeholder="Enter event description"
            />
          </Form.Item>

          <Form.Item
            name="event_type"
            label="Event Type"
            rules={[{ required: true, message: 'Please select event type' }]}
          >
            <Select placeholder="Select event type">
              <Option value="workshop">Workshop</Option>
              <Option value="fest">Fest</Option>
              <Option value="hackathon">Hackathon</Option>
              <Option value="seminar">Seminar</Option>
            </Select>
          </Form.Item>

          <Form.Item
            name="college_id"
            label="College"
            rules={[{ required: true, message: 'Please select college' }]}
          >
            <Select placeholder="Select college">
              {colleges.map(college => (
                <Option key={college.id} value={college.id}>
                  {college.name}
                </Option>
              ))}
            </Select>
          </Form.Item>

          <Form.Item
            name="dateRange"
            label="Date & Time"
            rules={[{ required: true, message: 'Please select date and time' }]}
          >
            <RangePicker
              showTime
              format="YYYY-MM-DD HH:mm"
              placeholder={['Start Date & Time', 'End Date & Time']}
            />
          </Form.Item>

          <Form.Item style={{ textAlign: 'right', marginBottom: 0 }}>
            <Space>
              <Button onClick={() => setModalVisible(false)}>
                Cancel
              </Button>
              <Button type="primary" htmlType="submit">
                {editingEvent ? 'Update' : 'Create'} Event
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  )
}

export default EventManagement
