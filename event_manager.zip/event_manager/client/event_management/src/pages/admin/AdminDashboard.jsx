import React from 'react'
import { Routes, Route } from 'react-router-dom'
import { Layout, Menu, Avatar, Dropdown, Typography, Space } from 'antd'
import {
  DashboardOutlined,
  CalendarOutlined,
  BarChartOutlined,
  UserOutlined,
  LogoutOutlined,
  TeamOutlined
} from '@ant-design/icons'
import { useAuth } from '../../context/AuthContext'
import { useNavigate, useLocation } from 'react-router-dom'
import EventManagement from './EventManagement'
import Reports from './Reports'
import StudentManagement from './StudentManagement'

const { Header, Sider, Content } = Layout
const { Text } = Typography

const AdminDashboard = () => {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [collapsed, setCollapsed] = React.useState(false)

  const menuItems = [
    {
      key: '/admin',
      icon: <DashboardOutlined />,
      label: 'Dashboard',
    },
    {
      key: '/admin/events',
      icon: <CalendarOutlined />,
      label: 'Event Management',
    },
    {
      key: '/admin/students',
      icon: <TeamOutlined />,
      label: 'Student Management',
    },
    {
      key: '/admin/reports',
      icon: <BarChartOutlined />,
      label: 'Reports & Analytics',
    },
  ]

  const handleMenuClick = ({ key }) => {
    navigate(key)
  }

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const userMenuItems = [
    {
      key: 'profile',
      icon: <UserOutlined />,
      label: 'Profile',
      onClick: () => navigate('/admin/profile'),
    },
    {
      key: 'logout',
      icon: <LogoutOutlined />,
      label: 'Logout',
      onClick: handleLogout,
    },
  ]

  const getSelectedKey = () => {
    const path = location.pathname
    if (path === '/admin') return ['/admin']
    if (path.startsWith('/admin/events')) return ['/admin/events']
    if (path.startsWith('/admin/students')) return ['/admin/students']
    if (path.startsWith('/admin/reports')) return ['/admin/reports']
    return ['/admin']
  }

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Sider
        collapsible
        collapsed={collapsed}
        onCollapse={setCollapsed}
        theme="dark"
      >
        <div style={{
          height: '64px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: '#001529',
          borderBottom: '1px solid #002140'
        }}>
          <Text style={{ color: 'white', fontSize: '18px', fontWeight: 'bold' }}>
            {collapsed ? '👑' : 'Admin Panel'}
          </Text>
        </div>

        <Menu
          theme="dark"
          mode="inline"
          selectedKeys={getSelectedKey()}
          items={menuItems}
          onClick={handleMenuClick}
        />
      </Sider>

      <Layout>
        <Header style={{
          background: '#fff',
          padding: '0 24px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <Text style={{ fontSize: '18px', fontWeight: 'bold' }}>
            Admin Dashboard
          </Text>

          <Space>
            <Text>Welcome, {user?.name || user?.username}</Text>
            <Dropdown
              menu={{ items: userMenuItems }}
              placement="bottomRight"
            >
              <Avatar
                style={{ cursor: 'pointer' }}
                icon={<UserOutlined />}
              />
            </Dropdown>
          </Space>
        </Header>

        <Content style={{
          margin: '24px 16px',
          padding: 24,
          background: '#fff',
          minHeight: 280,
          borderRadius: '8px'
        }}>
          <Routes>
            <Route path="/" element={<EventManagement />} />
            <Route path="/events" element={<EventManagement />} />
            <Route path="/students" element={<StudentManagement />} />
            <Route path="/reports" element={<Reports />} />
          </Routes>
        </Content>
      </Layout>
    </Layout>
  )
}

export default AdminDashboard
