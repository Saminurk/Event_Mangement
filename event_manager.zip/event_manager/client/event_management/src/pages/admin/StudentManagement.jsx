import React, { useState, useEffect } from 'react'
import {
  Card,
  Typography,
  Table,
  Input,
  Select,
  Space,
  Tag,
  Button,
  message,
  Spin,
  Avatar,
  Tooltip
} from 'antd'
import {
  SearchOutlined,
  UserOutlined,
  MailOutlined,
  TeamOutlined,
  CalendarOutlined,
  TrophyOutlined
} from '@ant-design/icons'
import { collegesAPI, reportsAPI } from '../../services/api'

const { Title, Text } = Typography
const { Option } = Select

const StudentManagement = () => {
  const [students, setStudents] = useState([])
  const [colleges, setColleges] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchText, setSearchText] = useState('')
  const [selectedCollege, setSelectedCollege] = useState('')

  useEffect(() => {
    fetchStudents()
    fetchColleges()
  }, [])

  const fetchStudents = async () => {
    try {
      setLoading(true)
      // Note: This would require a GET /students endpoint for admins
      // For now, we'll use the top students report as a placeholder
      const response = await reportsAPI.getTopStudents()
      const studentsWithDetails = response.data.map(student => ({
        id: student.student_id,
        name: student.name,
        email: `${student.name.toLowerCase().replace(' ', '.')}@college.edu`,
        college: 'Sample College',
        department: 'Computer Science',
        roll_no: `CS${student.student_id.toString().padStart(3, '0')}`,
        total_registrations: student.total_registrations,
        total_attendance: student.total_attendance,
        participation_score: student.participation_score,
        rank: student.rank
      }))
      setStudents(studentsWithDetails)
    } catch (error) {
      message.error('Failed to load students')
      console.error('Error fetching students:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchColleges = async () => {
    try {
      const response = await collegesAPI.getColleges()
      setColleges(response.data)
    } catch (error) {
      console.error('Error fetching colleges:', error)
    }
  }

  const filteredStudents = students.filter(student => {
    const matchesSearch = student.name.toLowerCase().includes(searchText.toLowerCase()) ||
                         student.email.toLowerCase().includes(searchText.toLowerCase()) ||
                         student.roll_no.toLowerCase().includes(searchText.toLowerCase())
    const matchesCollege = !selectedCollege || student.college_id === selectedCollege
    return matchesSearch && matchesCollege
  })

  const getParticipationLevel = (score) => {
    if (score >= 10) return { level: 'High', color: 'green' }
    if (score >= 5) return { level: 'Medium', color: 'orange' }
    return { level: 'Low', color: 'red' }
  }

  const columns = [
    {
      title: 'Student',
      key: 'student',
      render: (_, record) => (
        <Space>
          <Avatar icon={<UserOutlined />} />
          <div>
            <Text strong>{record.name}</Text>
            <br />
            <Text type="secondary" style={{ fontSize: '12px' }}>
              {record.roll_no}
            </Text>
          </div>
        </Space>
      )
    },
    {
      title: 'Contact',
      key: 'contact',
      render: (_, record) => (
        <Space direction="vertical" size={0}>
          <Space>
            <MailOutlined />
            <Text>{record.email}</Text>
          </Space>
          <Space>
            <TeamOutlined />
            <Text type="secondary" style={{ fontSize: '12px' }}>
              {record.college}
            </Text>
          </Space>
        </Space>
      )
    },
    {
      title: 'Department',
      dataIndex: 'department',
      key: 'department'
    },
    {
      title: 'Participation',
      key: 'participation',
      render: (_, record) => {
        const participation = getParticipationLevel(record.participation_score)
        return (
          <Space direction="vertical" size={4}>
            <Tag color={participation.color}>
              {participation.level}
            </Tag>
            <Text type="secondary" style={{ fontSize: '12px' }}>
              Score: {record.participation_score}
            </Text>
          </Space>
        )
      },
      sorter: (a, b) => a.participation_score - b.participation_score
    },
    {
      title: 'Registrations',
      dataIndex: 'total_registrations',
      key: 'total_registrations',
      render: (count) => <Text>{count}</Text>,
      sorter: (a, b) => a.total_registrations - b.total_registrations
    },
    {
      title: 'Attendance',
      dataIndex: 'total_attendance',
      key: 'total_attendance',
      render: (count) => <Text>{count}</Text>,
      sorter: (a, b) => a.total_attendance - b.total_attendance
    },
    {
      title: 'Rank',
      dataIndex: 'rank',
      key: 'rank',
      render: (rank) => rank ? (
        <Space>
          {rank <= 3 && <TrophyOutlined style={{
            color: rank === 1 ? '#FFD700' : rank === 2 ? '#C0C0C0' : '#CD7F32'
          }} />}
          <Text strong>{rank}</Text>
        </Space>
      ) : '-',
      sorter: (a, b) => (a.rank || 999) - (b.rank || 999)
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_, record) => (
        <Space>
          <Tooltip title="View Student Details">
            <Button
              type="text"
              icon={<UserOutlined />}
              onClick={() => message.info(`View details for ${record.name}`)}
            />
          </Tooltip>
          <Tooltip title="View Student Report">
            <Button
              type="text"
              icon={<CalendarOutlined />}
              onClick={() => message.info(`View report for ${record.name}`)}
            />
          </Tooltip>
        </Space>
      )
    }
  ]

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '50px' }}>
        <Spin size="large" />
        <div style={{ marginTop: '16px' }}>
          <Text>Loading students...</Text>
        </div>
      </div>
    )
  }

  return (
    <div>
      <div style={{ marginBottom: '24px' }}>
        <Title level={2}>Student Management</Title>
        <Text type="secondary">
          View and manage student information, participation, and performance
        </Text>
      </div>

      {/* Filters */}
      <Card style={{ marginBottom: '24px' }}>
        <Space size="large">
          <Input
            placeholder="Search by name, email, or roll number"
            prefix={<SearchOutlined />}
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            style={{ width: 300 }}
          />

          <Select
            placeholder="Filter by college"
            style={{ width: 200 }}
            value={selectedCollege}
            onChange={setSelectedCollege}
            allowClear
          >
            {colleges.map(college => (
              <Option key={college.id} value={college.id}>
                {college.name}
              </Option>
            ))}
          </Select>

          <Button
            onClick={() => {
              setSearchText('')
              setSelectedCollege('')
            }}
          >
            Clear Filters
          </Button>
        </Space>
      </Card>

      {/* Students Table */}
      <Card>
        <Table
          columns={columns}
          dataSource={filteredStudents}
          rowKey="id"
          pagination={{
            pageSize: 10,
            showSizeChanger: true,
            showQuickJumper: true,
            showTotal: (total, range) =>
              `${range[0]}-${range[1]} of ${total} students`
          }}
        />
      </Card>
    </div>
  )
}

export default StudentManagement
