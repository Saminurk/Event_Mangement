import React, { useState, useEffect } from 'react'
import {
  Card,
  Typography,
  Row,
  Col,
  Statistic,
  Table,
  Select,
  Space,
  Spin,
  message,
  Progress
} from 'antd'
import {
  BarChartOutlined,
  TeamOutlined,
  CalendarOutlined,
  TrophyOutlined,
  UserOutlined,
  CheckCircleOutlined
} from '@ant-design/icons'
import { reportsAPI } from '../../services/api'

const { Title, Text } = Typography
const { Option } = Select

const Reports = () => {
  const [eventReports, setEventReports] = useState([])
  const [topStudents, setTopStudents] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectedCollege, setSelectedCollege] = useState('')

  useEffect(() => {
    fetchReports()
  }, [selectedCollege])

  const fetchReports = async () => {
    try {
      setLoading(true)
      const [eventReportsResponse, topStudentsResponse] = await Promise.all([
        reportsAPI.getEventReports(),
        reportsAPI.getTopStudents()
      ])

      setEventReports(eventReportsResponse.data)
      setTopStudents(topStudentsResponse.data)
    } catch (error) {
      message.error('Failed to load reports')
      console.error('Error fetching reports:', error)
    } finally {
      setLoading(false)
    }
  }

  const eventColumns = [
    {
      title: 'Event',
      dataIndex: 'title',
      key: 'title',
      render: (text) => <Text strong>{text}</Text>
    },
    {
      title: 'Registrations',
      dataIndex: 'registration_count',
      key: 'registration_count',
      render: (count) => (
        <Space>
          <UserOutlined />
          <Text>{count}</Text>
        </Space>
      ),
      sorter: (a, b) => a.registration_count - b.registration_count
    },
    {
      title: 'Attendance',
      dataIndex: 'attendance_count',
      key: 'attendance_count',
      render: (count) => (
        <Space>
          <CheckCircleOutlined />
          <Text>{count}</Text>
        </Space>
      ),
      sorter: (a, b) => a.attendance_count - b.attendance_count
    },
    {
      title: 'Feedback',
      dataIndex: 'feedback_count',
      key: 'feedback_count',
      render: (count) => (
        <Space>
          <BarChartOutlined />
          <Text>{count}</Text>
        </Space>
      ),
      sorter: (a, b) => a.feedback_count - b.feedback_count
    },
    {
      title: 'Avg Rating',
      dataIndex: 'average_rating',
      key: 'average_rating',
      render: (rating) => rating ? `${rating.toFixed(1)}/5` : 'N/A',
      sorter: (a, b) => (a.average_rating || 0) - (b.average_rating || 0)
    },
    {
      title: 'Attendance Rate',
      key: 'attendance_rate',
      render: (_, record) => {
        const rate = record.registration_count > 0
          ? (record.attendance_count / record.registration_count) * 100
          : 0
        return (
          <Progress
            percent={Math.round(rate)}
            size="small"
            status={rate >= 80 ? 'success' : rate >= 60 ? 'normal' : 'exception'}
          />
        )
      }
    }
  ]

  const topStudentsColumns = [
    {
      title: 'Rank',
      dataIndex: 'rank',
      key: 'rank',
      render: (rank) => (
        <Space>
          {rank === 1 && <TrophyOutlined style={{ color: '#FFD700' }} />}
          {rank === 2 && <TrophyOutlined style={{ color: '#C0C0C0' }} />}
          {rank === 3 && <TrophyOutlined style={{ color: '#CD7F32' }} />}
          <Text strong>{rank}</Text>
        </Space>
      )
    },
    {
      title: 'Student',
      dataIndex: 'name',
      key: 'name',
      render: (name) => <Text strong>{name}</Text>
    },
    {
      title: 'Participation Score',
      dataIndex: 'participation_score',
      key: 'participation_score',
      render: (score) => <Text type="secondary">{score}</Text>,
      sorter: (a, b) => a.participation_score - b.participation_score
    },
    {
      title: 'Registrations',
      dataIndex: 'total_registrations',
      key: 'total_registrations',
      render: (count) => <Text>{count}</Text>,
      sorter: (a, b) => a.total_registrations - b.total_registrations
    },
    {
      title: 'Attendance',
      dataIndex: 'total_attendance',
      key: 'total_attendance',
      render: (count) => <Text>{count}</Text>,
      sorter: (a, b) => a.total_attendance - b.total_attendance
    }
  ]

  const calculateTotals = () => {
    const totalEvents = eventReports.length
    const totalRegistrations = eventReports.reduce((sum, event) => sum + event.registration_count, 0)
    const totalAttendance = eventReports.reduce((sum, event) => sum + event.attendance_count, 0)
    const totalFeedback = eventReports.reduce((sum, event) => sum + event.feedback_count, 0)
    const avgRating = eventReports.length > 0
      ? eventReports.reduce((sum, event) => sum + (event.average_rating || 0), 0) / eventReports.length
      : 0

    return {
      totalEvents,
      totalRegistrations,
      totalAttendance,
      totalFeedback,
      avgRating: avgRating.toFixed(1)
    }
  }

  const totals = calculateTotals()

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '50px' }}>
        <Spin size="large" />
        <div style={{ marginTop: '16px' }}>
          <Text>Loading reports...</Text>
        </div>
      </div>
    )
  }

  return (
    <div>
      <div style={{ marginBottom: '24px' }}>
        <Title level={2}>Reports & Analytics</Title>
        <Text type="secondary">
          Comprehensive insights into event performance and student participation
        </Text>
      </div>

      {/* Summary Statistics */}
      <Row gutter={[24, 24]} style={{ marginBottom: '24px' }}>
        <Col xs={24} sm={12} md={6}>
          <Card>
            <Statistic
              title="Total Events"
              value={totals.totalEvents}
              prefix={<CalendarOutlined />}
              valueStyle={{ color: '#1890ff' }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6}>
          <Card>
            <Statistic
              title="Total Registrations"
              value={totals.totalRegistrations}
              prefix={<UserOutlined />}
              valueStyle={{ color: '#52c41a' }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6}>
          <Card>
            <Statistic
              title="Total Attendance"
              value={totals.totalAttendance}
              prefix={<CheckCircleOutlined />}
              valueStyle={{ color: '#faad14' }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6}>
          <Card>
            <Statistic
              title="Average Rating"
              value={totals.avgRating}
              suffix="/5"
              prefix={<BarChartOutlined />}
              valueStyle={{ color: '#f5222d' }}
            />
          </Card>
        </Col>
      </Row>

      {/* Event Performance Report */}
      <Card style={{ marginBottom: '24px' }}>
        <div style={{ marginBottom: '16px' }}>
          <Title level={3}>Event Performance Report</Title>
          <Text type="secondary">
            Detailed analytics for all events including registration, attendance, and feedback metrics
          </Text>
        </div>
        <Table
          columns={eventColumns}
          dataSource={eventReports}
          rowKey="id"
          pagination={{
            pageSize: 10,
            showSizeChanger: true,
            showQuickJumper: true,
            showTotal: (total, range) =>
              `${range[0]}-${range[1]} of ${total} events`
          }}
        />
      </Card>

      {/* Top Students Report */}
      <Card>
        <div style={{ marginBottom: '16px' }}>
          <Title level={3}>Top Performing Students</Title>
          <Text type="secondary">
            Students with highest participation scores based on registrations, attendance, and feedback
          </Text>
        </div>
        <Table
          columns={topStudentsColumns}
          dataSource={topStudents}
          rowKey="student_id"
          pagination={false}
        />
      </Card>
    </div>
  )
}

export default Reports
