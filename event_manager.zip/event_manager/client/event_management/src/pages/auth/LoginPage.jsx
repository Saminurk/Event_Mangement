import React, { useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { Form, Input, Button, Card, Typography, message, Tabs, Space } from 'antd'
import { UserOutlined, LockOutlined, MailOutlined, IdcardOutlined, BankOutlined } from '@ant-design/icons'
import { useAuth } from '../../context/AuthContext'
import { collegesAPI } from '../../services/api'

const { Title, Text } = Typography
const { TabPane } = Tabs

const LoginPage = () => {
  const [loading, setLoading] = useState(false)
  const [colleges, setColleges] = useState([])
  const { login, register } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()

  const from = location.state?.from?.pathname || '/student'

  React.useEffect(() => {
    const fetchColleges = async () => {
      try {
        const response = await collegesAPI.getColleges()
        setColleges(response.data)
      } catch (error) {
        console.error('Failed to fetch colleges:', error)
      }
    }
    fetchColleges()
  }, [])

  const handleLogin = async (values) => {
    setLoading(true)
    try {
      const result = await login(values)
      if (result.success) {
        message.success('Login successful!')
        navigate(from, { replace: true })
      } else {
        message.error(result.error)
      }
    } catch (error) {
      message.error('Login failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const handleRegister = async (values) => {
    setLoading(true)
    try {
      const result = await register(values)
      if (result.success) {
        message.success('Registration successful!')
        navigate(from, { replace: true })
      } else {
        message.error(result.error)
      }
    } catch (error) {
      message.error('Registration failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const loginForm = (
    <Form
      name="login"
      onFinish={handleLogin}
      layout="vertical"
      size="large"
    >
      <Form.Item
        name="username"
        rules={[{ required: true, message: 'Please enter your username!' }]}
      >
        <Input
          prefix={<UserOutlined />}
          placeholder="Username"
        />
      </Form.Item>

      <Form.Item
        name="password"
        rules={[{ required: true, message: 'Please enter your password!' }]}
      >
        <Input.Password
          prefix={<LockOutlined />}
          placeholder="Password"
        />
      </Form.Item>

      <Form.Item>
        <Button
          type="primary"
          htmlType="submit"
          loading={loading}
          block
        >
          Log In
        </Button>
      </Form.Item>
    </Form>
  )

  const registerForm = (
    <Form
      name="register"
      onFinish={handleRegister}
      layout="vertical"
      size="large"
    >
      <Space direction="vertical" style={{ width: '100%' }}>
        <Form.Item
          name="username"
          rules={[
            { required: true, message: 'Please enter a username!' },
            { min: 3, message: 'Username must be at least 3 characters!' }
          ]}
        >
          <Input
            prefix={<UserOutlined />}
            placeholder="Username"
          />
        </Form.Item>

        <Form.Item
          name="email"
          rules={[
            { required: true, message: 'Please enter your email!' },
            { type: 'email', message: 'Please enter a valid email!' }
          ]}
        >
          <Input
            prefix={<MailOutlined />}
            placeholder="Email"
          />
        </Form.Item>

        <Form.Item
          name="name"
          rules={[{ required: true, message: 'Please enter your full name!' }]}
        >
          <Input
            prefix={<IdcardOutlined />}
            placeholder="Full Name"
          />
        </Form.Item>

        <Form.Item
          name="college_id"
          rules={[{ required: true, message: 'Please select your college!' }]}
        >
          <select
            style={{
              width: '100%',
              padding: '8px 12px',
              border: '1px solid #d9d9d9',
              borderRadius: '6px',
              fontSize: '16px'
            }}
          >
            <option value="">Select College</option>
            {colleges.map(college => (
              <option key={college.id} value={college.id}>
                {college.name}
              </option>
            ))}
          </select>
        </Form.Item>

        <Form.Item
          name="roll_no"
          rules={[{ required: true, message: 'Please enter your roll number!' }]}
        >
          <Input
            prefix={<IdcardOutlined />}
            placeholder="Roll Number"
          />
        </Form.Item>

        <Form.Item
          name="department"
          rules={[{ required: true, message: 'Please enter your department!' }]}
        >
          <Input
            prefix={<BankOutlined />}
            placeholder="Department"
          />
        </Form.Item>

        <Form.Item
          name="password"
          rules={[
            { required: true, message: 'Please enter a password!' },
            { min: 6, message: 'Password must be at least 6 characters!' }
          ]}
        >
          <Input.Password
            prefix={<LockOutlined />}
            placeholder="Password"
          />
        </Form.Item>

        <Form.Item>
          <Button
            type="primary"
            htmlType="submit"
            loading={loading}
            block
          >
            Register
          </Button>
        </Form.Item>
      </Space>
    </Form>
  )

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      padding: '20px'
    }}>
      <Card
        style={{
          width: '100%',
          maxWidth: '450px',
          boxShadow: '0 10px 30px rgba(0,0,0,0.1)'
        }}
      >
        <div style={{ textAlign: 'center', marginBottom: '24px' }}>
          <Title level={2} style={{ margin: 0, color: '#1890ff' }}>
            🎓 Campus Events
          </Title>
          <Text type="secondary">
            Manage your campus event experience
          </Text>
        </div>

        <Tabs defaultActiveKey="login" centered>
          <TabPane tab="Login" key="login">
            {loginForm}
          </TabPane>
          <TabPane tab="Register" key="register">
            {registerForm}
          </TabPane>
        </Tabs>
      </Card>
    </div>
  )
}

export default LoginPage
