import React, { createContext, useContext, useState, useEffect } from 'react'
import jwtDecode from 'jwt-decode'
import { authAPI } from '../services/api'

const AuthContext = createContext()

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [token, setToken] = useState(localStorage.getItem('access_token'))

  useEffect(() => {
    if (token) {
      try {
        const decoded = jwtDecode(token)
        // Backend sends user data directly, not in JWT
        // We'll store user data separately
        const storedUser = localStorage.getItem('user_data')
        if (storedUser) {
          setUser(JSON.parse(storedUser))
        }
      } catch (error) {
        console.error('Invalid token:', error)
        localStorage.removeItem('access_token')
        localStorage.removeItem('user_data')
        setToken(null)
        setUser(null)
      }
    }
    setLoading(false)
  }, [token])

  const login = async (credentials) => {
    try {
      const response = await authAPI.login(credentials)
      const { access_token, user: userData } = response.data

      localStorage.setItem('access_token', access_token)
      localStorage.setItem('user_data', JSON.stringify(userData))
      setToken(access_token)
      setUser(userData)

      return { success: true }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.detail || 'Login failed'
      }
    }
  }

  const register = async (userData) => {
    try {
      const response = await authAPI.register(userData)
      const { access_token, user: newUser } = response.data

      localStorage.setItem('access_token', access_token)
      localStorage.setItem('user_data', JSON.stringify(newUser))
      setToken(access_token)
      setUser(newUser)

      return { success: true }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.detail || 'Registration failed'
      }
    }
  }

  const logout = () => {
    localStorage.removeItem('access_token')
    localStorage.removeItem('user_data')
    setToken(null)
    setUser(null)
  }

  const isAuthenticated = !!user
  const isStudent = user && !user.is_staff
  const isAdmin = user && user.is_staff

  const value = {
    user,
    token,
    loading,
    login,
    register,
    logout,
    isAuthenticated,
    isStudent,
    isAdmin
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}
